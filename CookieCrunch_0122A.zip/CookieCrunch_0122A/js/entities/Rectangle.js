var Rectangle = cc.Class.extend({
    _drawNode: null,
    _layer: null,

    init: function(layer) {
        this._drawNode = cc.DrawNode.create();
        this._layer = layer;

        this._layer.addChild(this._drawNode);
    },

    drawShape: function(x, y, width, height) {
        var origin = new cc.Point(x, y);
        var destination = new cc.Point(origin.x + width, origin.y + height);

        var winSize = {height: ResolutionManager.getInstance().getScreenHeight(), width: ResolutionManager.getInstance().getScreenWidth()};
        var points = [ cc.p(winSize.height/4,0), cc.p(winSize.width,winSize.height/5), cc.p(winSize.width/3*2,winSize.height) ];
        this._drawNode.drawPoly(points, cc.c4f(1,0,0,0.5), 4, cc.c4f(0,0,1,1) );
    }
});