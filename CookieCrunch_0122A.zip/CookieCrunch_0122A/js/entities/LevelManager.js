/**
 * Created by neil.delgallego on 1/6/14.
 */
var LevelManager = cc.Class.extend
({
    _sharedInstance: null,
    _currentLevel: 0,
    _levelList: [],

    init: function()
    {
        this._currentLevel = 1;

        for(var lvl = 1; lvl <= LevelManager.MAX_LEVEL; lvl++)
        {
            var lvlResource = CocosResources.getInstance().getDataResource('level' + lvl)[0];
            var data = new LevelData();
            data.init(lvl, lvlResource['max_score'], lvlResource['moves']);
            //if(lvl == 1)
            {
                data.unlockLevel();
            }

            this._levelList.push(data);
        }
    },

    setLevel: function(level)
    {
        this._currentLevel = level;
    },

    //returns the current level to be parsed
    getCurrentLevel: function()
    {
        return this._currentLevel;
    },

    getCurrentLevelData: function()
    {
        var lvl = this._currentLevel - 1;
        if(lvl < 0 || lvl >= this._levelList.length) return null;
        return this._levelList[lvl];
    },

    getLevelData: function(lvl)
    {
        lvl = lvl - 1;
        if(lvl < 0 || lvl >= this._levelList.length) return null;
        return this._levelList[lvl];
    },

    unlockNextLevel: function()
    {
        //current level is the last level
        var lvl = this._currentLevel - 1;
        if(lvl + 1 >= this._levelList.length) return;
        this._levelList[lvl + 1].unlockLevel();
    }
});

LevelManager.getInstance = function() {
    if(LevelManager._sharedInstance == null) {
        LevelManager._sharedInstance = new LevelManager();
        LevelManager._sharedInstance.init();
    }

    return LevelManager._sharedInstance;
}

LevelManager.MAX_LEVEL = 48;

var LevelData = cc.Class.extend({
    level: 0,
    highestScore: 0,
    objectiveScore: 0,
    moves: 0,
    locked: true,

    init:function(lvl, objScore, moveCnt)
    {
        this.level = lvl;
        this.objectiveScore = objScore;
        this.moves = moveCnt;
    },

    getLevel: function()
    {
        return this.level;
    },

    setScore: function(score)
    {
        if(this.highestScore < score)
        {
            this.highestScore = score;
        }
    },

    getScore: function()
    {
        return this.highestScore;
    },

    getHeartRating: function()
    {
        var ratio = (this.highestScore / this.objectiveScore) * 100;
        return ratio >= 100 ? 3 : ratio >= 80 ? 2 : ratio >= 50 ? 1 : 0;
    },

    getTargetScore: function()
    {
        return this.objectiveScore;
    },

    getMoveCount: function()
    {
        return this.moves;
    },

    isLocked: function()
    {
        return this.locked;
    },

    unlockLevel: function()
    {
        this.locked = false;
    }
});