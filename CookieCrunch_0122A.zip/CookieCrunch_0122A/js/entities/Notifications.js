/**
 * Holder of notification events
 * Created by neil.delgallego on 1/8/14.
 */
var Notifications = cc.Class.extend({

});

Notifications.MSG_CHECK_PATTERN = "MSG_CHECK_PATTERN";
Notifications.MSG_SWAP_PATTERN = "MSG_SWAP_PATTERN";
Notifications.MSG_CLEARING = "MSG_CLEARING";
Notifications.MSG_FINISH_CLEARING = "MSG_FINISH_CLEARING";
Notifications.MSG_OUT_OF_MOVES = "MSG_OUT_OF_MOVES";
Notifications.MSG_REACHED_TARGET_SCORE = "MSG_REACHED_TARGET_SCORE";
Notifications.MSG_COUNTED_COMBO = "MSG_COUNTED_COMBO";

//powerup update of quantity
Notifications.MSG_CONSUMED_POWERUP = "MSG_CONSUMED_POWERUP";
Notifications.MSG_ADDED_POWERUP = "MSG_ADDED_POWERUP";

//deadlocks
Notifications.MSG_DEADLOCK_REACHED = "MSG_DEADLOCK_REACHED";
