/**
 * Contains all the enums in the game.
 * Created by neil.delgallego on 1/6/14.
 */

var GameEnums = cc.Class.extend({

});

GameEnums.GridType = {
    NORMAL : 1,
    BLOCKED: 0
}

GameEnums.MAX_POWERUP_COUNT = 2;
GameEnums.NumCookieTypes = 11;
GameEnums.CookieType = {
    CHOCOLATE_CHIP : 0,
    SPRINKED: 1,
    PEANUT_BUTTER: 2,
    OREO: 3,
    FUDGE_BROWNIE: 4,
    SUGAR_COOKIE_HEART: 5,
    SUGAR_COOKIE_STAR: 6,
    PLAIN_ANIMAL_CRACKER: 7,
    CANDY: 8,
    POWERUP_MILK: 9,
    POWERUP_COOKIE_CUTTER: 10,
    POWERUP_HANDS: 11,
    WILDCARD_ICECREAM: 12,
    WILDCARD_WHIPCREAM: 13

}

GameEnums.CookieState = {
    NORMAL : "NORMAL",
    MOVE: "MOVE",
    DESTROY: "DESTROY"
}

GameEnums.SwipeDirection = {
    UP: 0,
    DOWN: 1,
    LEFT: 2,
    RIGHT: 3
}
