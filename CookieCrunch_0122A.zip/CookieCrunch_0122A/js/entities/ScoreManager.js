/**
 * Created by neil.delgallego on 1/13/14.
 */

const SCORE_THREE_MATCH = 1000;
const SCORE_FOUR_MATCH = 2500;
const SCORE_FIVE_MATCH = 5000;

const MAX_TALLY_MATCH = 5;
var ScoreManager = cc.Class.extend({
    _sharedInstance: null,
    _numMoves: 0,
    _currentScore: 0,
    _scoreEarned: 0,
    _targetScore: 0,
    _uiTextMap: [],
    _scoreUpdateSignal: null,

    ctor: function() {

    },

    reset: function() {
        this._currentScore = 0;
        this._scoreEarned = 0;
        this._scoreUpdateSignal = new signals.Signal();
    },

    setScoreValuesForCurrentLevel: function() {
        var level = LevelManager.getInstance().getCurrentLevel();

        var levelData = CocosResources.getInstance().getDataResource('level' + level)[0];
        this._numMoves = levelData['moves'];
        this._targetScore = levelData['objective_score'];
    },

    //binds a UI text and automatically updates its label for changes in score
    bindUIText: function(uiText, key) {
        this._uiTextMap[key] = uiText;
        this.updateTextValues();
    },

    addMoves: function(qty) {
        this._numMoves+=qty;
        this.updateTextValues();
    },

    deductMoves: function() {
        if(this.hasMovesLeft()) {
            this._numMoves--;
        }

        this.updateTextValues();
    },

    updateScore: function(tally) {

       var comboDetector = ComboDetector.getInstance();


       switch(tally) {
           case 3:
               comboDetector.addCombo();
               this._scoreEarned = SCORE_THREE_MATCH * comboDetector.getComboMultiplier();
               this._currentScore += this._scoreEarned;
               console.log("Score added: " +(SCORE_THREE_MATCH * comboDetector.getComboMultiplier()));

               gNotification.postNotification(Notifications.MSG_COUNTED_COMBO, this);
               break;
           case 4:
               comboDetector.addCombo();
               this._scoreEarned = SCORE_FOUR_MATCH * comboDetector.getComboMultiplier();
               this._currentScore += this._scoreEarned;
               console.log("Score added: " +(SCORE_FOUR_MATCH * comboDetector.getComboMultiplier()));

               gNotification.postNotification(Notifications.MSG_COUNTED_COMBO, this);
               break;
           case 5:
               comboDetector.addCombo();
               this._scoreEarned = SCORE_FIVE_MATCH * comboDetector.getComboMultiplier();
               this._currentScore += this._scoreEarned;
               console.log("Score added: " +(SCORE_FIVE_MATCH * comboDetector.getComboMultiplier()));

               gNotification.postNotification(Notifications.MSG_COUNTED_COMBO, this);
               break;
           default: break;
       }

       this._scoreUpdateSignal.dispatch(this._currentScore);
       this.updateTextValues();

    },

    getScoreEarned: function() {
        return this._scoreEarned;
    },

    hasMovesLeft: function() {
        if(this._numMoves > 0) {
            return true;
        }
        else {
            return false;
        }
    },

    hasReachedTargetScore: function() {
        if(this._currentScore >= this._targetScore) {
            return true;
        }
        else {
            return false;
        }
    },

    updateTextValues: function() {
        //update moves
        var movesText = this._uiTextMap[ScoreManager.UITextKeys.MOVES_UI_TEXT];
        var scoreText = this._uiTextMap[ScoreManager.UITextKeys.SCORE_UI_TEXT];
        var targetScoreText = this._uiTextMap[ScoreManager.UITextKeys.TARGET_SCORE_UI_TEXT];

        if(movesText != null)
            movesText.setString(this._numMoves);

        if(scoreText != null) {
            scoreText.setString(this._currentScore);
        }

        if(targetScoreText != null) {
            targetScoreText.setString(this._targetScore);
        }
    }
});

ScoreManager.getInstance = function() {
    if(ScoreManager._sharedInstance == null) {
        ScoreManager._sharedInstance = new ScoreManager();
    }

    return ScoreManager._sharedInstance;
}

ScoreManager.UITextKeys = {
    MOVES_UI_TEXT : "MOVES_UI_TEXT",
    SCORE_UI_TEXT: "SCORE_UI_TEXT",
    TARGET_SCORE_UI_TEXT: "TARGET_SCORE_UI_TEXT"
}

