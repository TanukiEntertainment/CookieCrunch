/**
 * Allows chancing of pieces by pressing CTRL
 * Created by neil.delgallego on 1/14/14.
 */

var DebugKeyboard = cc.Class.extend({

    _isCheatActive: false,
    _sharedInstance: null,

    ctor: function() {

    },

    setCheatActive: function(flag) {
        this._isCheatActive = flag;
    },

    isCheatActive: function() {
        return this._isCheatActive;
    }
});

DebugKeyboard.getInstance = function() {
    if(DebugKeyboard._sharedInstance == null) {
        DebugKeyboard._sharedInstance = new DebugKeyboard();
    }

    return DebugKeyboard._sharedInstance;
}
