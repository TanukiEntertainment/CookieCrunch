/**
 * Parses the grid given an input JSON file
 * Created by neil.delgallego on 1/6/14.
 */

const GRID_MAX_ROW = 8;
const GRID_MAX_COLUMN = 8;

var GridParser = cc.Class.extend({
    _gridContainer: null,
    _uiContainer: null,
    _gridMatrix: null,
    _afterAction: null,
    _xOffset : 8.0,
    _yOffset : 10.0,

    init: function(gridMatrix, action) {
        this._gridContainer = new cc.Layer.create();
        this._gridContainer.init();
        this._gridMatrix = gridMatrix;
        this._afterAction = action;
    },

    parseLevel: function(level, container) {
        var levelData = CocosResources.getInstance().getDataResource('level' +level);

        this._uiContainer = container;
        //console.log("level src read: " +JSON.stringify(levelData));
        this.onParsedLevelData(levelData);
        //$.getJSON(levelSrc, this.onParsedLevelData.bind(this));
    },

    //sets the position of the container. the container's anchor point is at the center
    setPositionOfContainer: function(x, y) {
        this._gridContainer.setPosition(new cc.Point(x,y));
    },

    onParsedLevelData: function(data) {
        var levelData = data[0];

        var x = this._xOffset;
        var y = this._yOffset;
        var row = GRID_MAX_ROW - 1;
        var col = 0;

        for(var i = 0; i < levelData['board'].length; i++) {
            //console.log("Board Data: " +levelData['board'][i]+ " index: " +i);
            if(i % GRID_MAX_COLUMN == 0 && i != 0) {
                x = this._xOffset;
                col = 0; row--;
                y += sprite.getContentSize().height;
            }

            var sprite = new TileSprite();
            sprite.init(parseInt(levelData['board'][i]));
            sprite.setAnchorPoint(new cc.Point(0.5,0.5));
            sprite.setPosition(CoordsConverter.convertCoordinates(x,y,2));
            x += sprite.getContentSize().width;

            this._gridMatrix[row][col] = sprite; col++;
            this._gridContainer.addChild(sprite);
        }

        this._uiContainer.addChild(this._gridContainer);
        this._afterAction.execute();
    },

    getGridContainer: function() {
        return this._gridContainer;
    }
});