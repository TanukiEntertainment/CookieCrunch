/**
 * Represents the grid matrix
 * Created by neil.delgallego on 1/7/14.
 */

var GridMatrix = cc.Class.extend({
    _gridMatrixArr: null,

    init: function() {
        this.createGridMatrix();
    },

    createGridMatrix: function() {
        this._gridMatrixArr = [];

        for(var row = 0; row < GRID_MAX_ROW; row++) {
            this._gridMatrixArr[row] = [];

            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                this._gridMatrixArr[row][col] = null; //default value
            }
        }
    },

    setGridAt: function(row, col, object) {
        this._gridMatrixArr[row][col] = object;
    },

    getGridAt: function(row, col) {
        return this._gridMatrixArr[row][col];
    }
})


