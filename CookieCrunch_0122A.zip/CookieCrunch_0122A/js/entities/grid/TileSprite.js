/**
 * Created by neil.delgallego on 1/6/14.
 */

var TileSprite = cc.Sprite.extend({

    _assetKey: null,
    _gridType: null,
    _resourceInstance: null,

    ctor: function() {
        this._super();
    },

    init: function(gridType) {
        this._gridType = gridType;
        this._resourceInstance = CocosResources.getInstance();
        this.loadTextureBasedFromGridType();
    },

    loadTextureBasedFromGridType: function() {
        if(this._gridType == GameEnums.GridType.NORMAL) {
            this.initWithSpriteFrameName(this._resourceInstance.getFileNameOfRes('PNG_NORMAL_TILE'));
            //this.initWithFile(this._resourceInstance.getResource('PNG_NORMAL_TILE'))
        }
        else if(this._gridType == GameEnums.GridType.BLOCKED) {
            this.initWithSpriteFrameName(this._resourceInstance.getFileNameOfRes('PNG_BLOCKED_TILE'));
            //this.initWithFile(this._resourceInstance.getResource('PNG_BLOCKED_TILE'));
        }
    },

    getGridType: function() {
        return this._gridType;
    }

});