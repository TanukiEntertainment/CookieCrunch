/**
 * Represents the cookie in the grid. Inherits grid object
 * Created by neil.delgallego on 1/7/14.
 */

const MAX_OFFSET_FOR_SWIPE = 40;
const MAX_SCALE_FACTOR = 3.0;
var CookieObject = cc.Sprite.extend({
    _cookieType : null,
    _cookieState: GameEnums.CookieState.NORMAL,
    _row: 0,
    _col: 0,
    _handleTouch: false,
    _swapDirection: null,
    _isRecover: false,
    _isSwapEnabled: true,
    _swapPattern: null,
    _removeBatchIndex: 0,
    _gameStateTracker: null,

    _debugKeyCtrlDown: false,
    _scaleFactor: 1,

    _animAction : null,
    _atlasLayer: null,
    _animSprite: null,

    ctor: function(cookieType) {
        this._super();

        this.init(cookieType);
    },

    init: function(cookieType) {
        this._super();

        this._cookieType = cookieType;
        this._cookieState = GameEnums.CookieState.NORMAL;
        this._gameStateTracker = GameStateTracker.getInstance();
        this.initWithSpriteFrameName(this.findCorrespondingAtlasKey());

        this.setCookieScale(this._scaleFactor);

    },

    setCookieScale: function(scaleFactor) {
        this._scaleFactor = scaleFactor;

        if(this._cookieType != GameEnums.CookieType.POWERUP_MILK && this._cookieType != GameEnums.CookieType.POWERUP_COOKIE_CUTTER
            && this._cookieType != GameEnums.CookieType.POWERUP_HANDS) {
            var divider = this._scaleFactor * 1.0 / MAX_SCALE_FACTOR;
            this.setScale(divider, divider);
        }

    },

    setSwapEnabled: function(flag) {
        this._isSwapEnabled = flag;
    },

    isSwappingEnabled: function() {
        return this._isSwapEnabled;
    },

    findCorrespondingAtlasKey: function() {
        switch(this._cookieType) {
            case GameEnums.CookieType.CHOCOLATE_CHIP : return 'INGAME_COOKIE_ChocoChip.png';
            case GameEnums.CookieType.CANDY: return 'INGAME_COOKIE_Candy.png';
            case GameEnums.CookieType.PLAIN_ANIMAL_CRACKER: return 'INGAME_COOKIE_Animal.png';
            case GameEnums.CookieType.FUDGE_BROWNIE: return 'INGAME_COOKIE_FudgeBrownie.png';
            case GameEnums.CookieType.SUGAR_COOKIE_HEART: return 'INGAME_COOKIE_Heart.png';
            case GameEnums.CookieType.OREO: return 'INGAME_COOKIE_Oreo.png';
            case GameEnums.CookieType.SPRINKED: return 'INGAME_COOKIE_Sprinkled.png';
            case GameEnums.CookieType.SUGAR_COOKIE_STAR: return 'INGAME_COOKIE_Star.png';
            case GameEnums.CookieType.PEANUT_BUTTER: return 'INGAME_COOKIE_PeanutButter.png';
            case GameEnums.CookieType.WILDCARD_ICECREAM: return 'INGAME_WILDCARD_IceCream.png';
            case GameEnums.CookieType.WILDCARD_WHIPCREAM: return 'INGAME_WILDCARD_WhippedCream.png';
            case GameEnums.CookieType.POWERUP_MILK: return 'INGAME_Booster_Milk.png';
            case GameEnums.CookieType.POWERUP_COOKIE_CUTTER: return 'INGAME_Booster_CookieCutter.png';
            case GameEnums.CookieType.POWERUP_HANDS: return 'INGAME_Booster_Hands.png';
        }


    },

    setRemoveBatchIndex: function(index) {
        this._removeBatchIndex = index;
    },

    getRemoveBatchIndex: function() {
        return this._removeBatchIndex;
    },

    setSwapPattern: function(swapPattern) {
        this._swapPattern = swapPattern;
    },

    getSwapPattern: function() {
        return this._swapPattern;
    },

    setRecover: function(value) {
        this._isRecover = value;
    },

    isRecovering: function() {
        return this._isRecover;
    },

    getCookieType: function() {
        return this._cookieType;
    },

    getCookieState: function() {
        return this._cookieState;
    },

    setCookieState: function(state) {
        this._cookieState = state;
    },

    getSwipeDirection: function() {
        return this._swapDirection;
    },

    setGridPosition: function(row, col) {
        this._row = row;
        this._col = col;
    },

    getRow: function() {
        return this._row;
    },

    getColumn: function() {
        return this._col;
    },

    moveTo:function( duration,  position){
        if (this._cookieState == GameEnums.CookieState.NORMAL)
        {
            this._cookieState = GameEnums.CookieState.MOVE;
            var action = cc.Sequence.create(cc.EaseSineOut.create(cc.MoveTo.create(duration,position)),cc.CallFunc.create(this.onMoveEnd.bind(this),this));
            this.runAction(action);
        }
    },

    onMoveEnd: function() {
        this._cookieState = GameEnums.CookieState.NORMAL;
    },

    swapTo:function(duration, position){
        if (this._cookieState === GameEnums.CookieState.NORMAL)
        {
            this._cookieState = GameEnums.CookieState.MOVE;
            this.runAction(cc.MoveTo.create(duration,cc.p(position.x,position.y)));
        }
    },

    //animation if this was marked as a hint
    highlight: function() {
        //for now, we use fade out
        var scaleTo = new cc.ScaleTo.create(0.3, this.getScaleX() * 1.5);
        var scaleDef = new cc.ScaleTo.create(0.3, this.getScaleX());
        var scaleSequence = new cc.Sequence.create(cc.DelayTime.create(8.0),scaleTo, scaleDef);

        if(this.getNumberOfRunningActions() == 0 && GameStateTracker.getInstance().getCurrentGameState() == GameStateTracker.GameState.AWAITING_INPUT) {
            this.runAction(scaleSequence);
        }
    },

    destroy: function() {
        this._cookieState = GameEnums.CookieState.DESTROY;

        if(this._cookieType != GameEnums.CookieType.POWERUP_MILK && this._cookieType != GameEnums.CookieType.POWERUP_COOKIE_CUTTER
            && this._cookieType != GameEnums.CookieType.POWERUP_HANDS) {

            //add effects here
            this._atlasLayer = new AtlasLayer();
            var animFrames = this._atlasLayer.getAnimation('crumble_');
            animFrames.setRestoreOriginalFrame(true);
            animFrames.setDelayPerUnit(0.08);
            animFrames.setLoops(1);

            var width = this.getContentSize().width;
            var height = this.getContentSize().height;
            this._animAction = new cc.Animate.create(animFrames);
            this._animSprite = cc.Sprite.createWithSpriteFrameName('crumble_1.png'); //create initial animation of crumble
            this._animSprite.setScale(3.0, 3.0);
            this._animSprite.setPosition(new cc.Point(width * 0.5, height * 0.5));
            this.addChild(this._animSprite);

            //add animation
            this._animSprite.runAction(this._animAction);
        }

        this.runAction(cc.FadeOut.create(PATTERN_CLEAR_TIME));

        //play audio
    },

    containsTouchLocation:function (touch) {
        var getPoint = touch.getLocation();
        var worldPt = this.getParent().convertToWorldSpace(this.getPosition());

        var lx = 0 | (getPoint.x -  worldPt.x);//this.getPositionX();
        var ly = 0 | (getPoint.y -  worldPt.y);//this.getPositionY();


        if(lx>-40 && lx<40 && ly>-40&& ly<40)
            return true;
        return false;
    },

    onTouchBegan: function(touch, event) {

        if(this._cookieState == GameEnums.CookieState.NORMAL && this.containsTouchLocation(touch)
            && this._gameStateTracker.getCurrentGameState() == GameStateTracker.GameState.AWAITING_INPUT) {
            this._handleTouch = true;

            if(DebugKeyboard.getInstance().isCheatActive()) {
                this._cookieType = GameEnums.CookieType.POWERUP_MILK;
                this.initWithSpriteFrameName(this.findCorrespondingAtlasKey());
            }
            if(PowerUpsHandler.getInstance().hasPowerUpActive()) {
                PowerUpsHandler.getInstance().consumePowerUp(this);
            }
            else {
                gNotification.postNotification(Notifications.MSG_CHECK_PATTERN, this);
            }

            return true;
        }
        else {
            return false;
        }

    },

    onTouchMoved: function(touch, event) {
         //determine swipe direction
         if(this._handleTouch && this._cookieState == GameEnums.CookieState.NORMAL) {
             var getPoint = touch.getLocation();
             var worldPt = this.getParent().convertToWorldSpace(this.getPosition());

             var lx = 0 | (getPoint.x -  worldPt.x);
             var ly = 0 | (getPoint.y -  worldPt.y);

             //console.log("LX: " +lx+ " Y: "+ly);
             if(lx > MAX_OFFSET_FOR_SWIPE) {
                 this._handleTouch = false;
                 if (ly > lx)
                     this._swapDirection = GameEnums.SwipeDirection.UP;
                 else if (ly + lx < 0)
                     this._swapDirection = GameEnums.SwipeDirection.DOWN;
                 else
                     this._swapDirection = GameEnums.SwipeDirection.RIGHT;
                 gNotification.postNotification(Notifications.MSG_SWAP_PATTERN,this);
             }
             else if(lx < -MAX_OFFSET_FOR_SWIPE) {
                 this._handleTouch = false;
                 if (ly < lx)
                     this._swapDirection = GameEnums.SwipeDirection.DOWN;
                 else if(ly + lx > 0)
                     this._swapDirection = GameEnums.SwipeDirection.UP;
                 else
                     this._swapDirection = GameEnums.SwipeDirection.LEFT;
                 gNotification.postNotification(Notifications.MSG_SWAP_PATTERN,this);
             }
             else if(ly > MAX_OFFSET_FOR_SWIPE) {
                 this._handleTouch = false;
                 this._swapDirection = GameEnums.SwipeDirection.UP;
                 gNotification.postNotification(Notifications.MSG_SWAP_PATTERN,this);
             }
             else if(ly < -MAX_OFFSET_FOR_SWIPE) {
                 this._handleTouch = false;
                 this._swapDirection = GameEnums.SwipeDirection.DOWN;
                 gNotification.postNotification(Notifications.MSG_SWAP_PATTERN,this);
             }
         }
    },

    onEnter:function () {
        if(sys.platform == "browser")
            cc.registerTargetedDelegate(1, true, this);
        else
            cc.registerTargettedDelegate(1,true,this);
        this._super();
    },

    onExit:function () {
        cc.unregisterTouchDelegate(this);
        this._super();
    }
});

//we use this as a flag for 2x2 or 3x3 grid objects to restrict tile gravity of cookies adjacent to it.
CookieObject.dummyObject = "DUMMY";
