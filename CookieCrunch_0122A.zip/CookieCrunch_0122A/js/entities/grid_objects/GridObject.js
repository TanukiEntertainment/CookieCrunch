/**
 * Represents the object to be placed in the grid
 * Created by neil.delgallego on 1/7/14.
 */

var GridObject = cc.Sprite.extend({

    _atlasKey: null,

    ctor: function() {
        this._super();
    },

    init: function(atlasAssetKey) {
        this._atlasKey = atlasAssetKey;
        this.initWithSpriteFrameName(this._atlasKey);
    },

    initUsingTextureListId: function(textureKey) {
        this._atlasKey = CocosResources.getInstance().getFileNameOfRes(textureKey);
        this.initWithSpriteFrameName(this._atlasKey);
    }
});