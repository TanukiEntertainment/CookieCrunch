/**
 * Checks if the given row and col is within the bounds
 * Created by neil.delgallego on 1/14/14.
 */
var BoundsChecker = cc.Class.extend({

});

BoundsChecker.isWithinBounds = function(row,col) {
    var result = false;

    if(row >= 0 && row < GRID_MAX_ROW) {
        if(col >= 0 && col < GRID_MAX_COLUMN) {
            result = true;
        }
    }

    return result;
}
