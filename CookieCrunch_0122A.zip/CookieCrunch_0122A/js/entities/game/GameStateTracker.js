/**Tracks the state of the game in match 3.
 * Created by neil.delgallego on 1/10/14.
 */

var GameStateTracker = cc.Class.extend({
    _sharedInstance: null,
    _gameState: null,

    ctor: function() {
        this._gameState = GameStateTracker.GameState.AWAITING_INPUT;
    },

    setGameState: function(gameState) {
        this._gameState = gameState;
    },

    getCurrentGameState: function() {
        console.log("GameState: " +this._gameState);
        return this._gameState;
    }
});

GameStateTracker.getInstance = function() {
    if(GameStateTracker._sharedInstance == null) {
        GameStateTracker._sharedInstance = new GameStateTracker();
    }

    return GameStateTracker._sharedInstance;
}

GameStateTracker.GameState = {
    AWAITING_INPUT: "AWAITING_INPUT",
    PERFORMING_MATCH: "PERFORMING_MATCH",
    GAME_PAUSED: "GAME_PAUSED",
    EXCLUDING_DEADLOCK: "EXCLUDING_DEADLOCK",
    END_OF_GAME: "END_OF_GAME"
}
