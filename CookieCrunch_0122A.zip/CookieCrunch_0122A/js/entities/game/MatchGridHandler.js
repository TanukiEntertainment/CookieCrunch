/**
 * Handles the checking of patterns for matches and the proper handling of grid and gravity
 * Created by neil.delgallego on 1/8/14.
 */

var MINIMUM_CONTINUOUS_COUNT = 3;
var MAXIMUM_CONTINUOUS_COUNT = 5;

const PATTERN_SWAP_TIME = 0.17;
const PATTERN_CLEAR_TIME = 0.24;
const PATTERN_FALL_TIME = 0.4;
const PATTERN_GRAVITY_TIME = 0.15;

var MatchGridHandler = cc.Class.extend({
    _gridContainer: null,
    _gridMatrix: null,
    _objectMatrix: null,
    _destroyBatchTally: 0,
    _gridVerifier: null,
    _sandwichCreator: null,

    _milkCount: 0,
    _cookieCutterCount: 0,
    _handsCount: 0,

    _hasFoundPowerUp: false,
    _spawnPowerUpsRestricted: true,
    _hasNotifiedDeadlock: false,
    _isPerformingClearing: false,

    ctor: function(gridContainer,gridMatrix, objectMatrix) {
        this._gridContainer = gridContainer;
        this._gridMatrix = gridMatrix;
        this._objectMatrix = objectMatrix;
        //reference for successful matches

        //instantiate grid verifier
        this._gridVerifier = new GridVerifier(this._objectMatrix);
        this._sandwichCreator = new CookieSandwichCreator(this._objectMatrix, this._gridMatrix, this._gridVerifier, this._gridContainer);
        PowerUpsHandler.getInstance().assignMatchGridHandler(this);
    },

    createGridObjects: function() {
        for(var row = 0; row < GRID_MAX_ROW; row++) {
            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                this.createOneGridObject(row, col);
            }
        }

        this._spawnPowerUpsRestricted = false;
        this._gridContainer.runAction(cc.Sequence.create(cc.DelayTime.create(PATTERN_FALL_TIME+0.1),
            cc.CallFunc.create(this.detectAnyMatches.bind(this))));
    },

    getObjectMatrix: function() {
        return this._objectMatrix;
    },

    getRandomCookieType: function() {
        var rand = Math.random() * 10000;
        var cookieType = Math.round(rand % GameEnums.NumCookieTypes);

        //we impose limits to powerups
        if(cookieType == GameEnums.CookieType.POWERUP_MILK) {
            if(this._milkCount < GameEnums.MAX_POWERUP_COUNT && !this._spawnPowerUpsRestricted) {
                this._milkCount++;
                return cookieType;
            }
            else {
                return this.getRandomCookieType();
            }
        }

        else if(cookieType == GameEnums.CookieType.POWERUP_COOKIE_CUTTER) {
            if(this._cookieCutterCount < GameEnums.MAX_POWERUP_COUNT && !this._spawnPowerUpsRestricted) {
                this._cookieCutterCount++;
                return cookieType;
            }
            else {
                return this.getRandomCookieType();
            }
        }

        else if(cookieType == GameEnums.CookieType.POWERUP_HANDS) {
            if(this._handsCount < GameEnums.MAX_POWERUP_COUNT && !this._spawnPowerUpsRestricted) {
                this._handsCount++;
                return cookieType;
            }
            else {
                return this.getRandomCookieType();
            }
        }

        else {
            return cookieType;
        }



    },

    createOneGridObject: function(row, col) {
        //randomize cookie type
        var cookieType = this.getRandomCookieType();

        //check if the grid can have an object
        if(this._gridMatrix[row][col].getGridType() == GameEnums.GridType.BLOCKED) {
            return;
        }

        var cookieObj = new CookieObject(cookieType);
        cookieObj.setAnchorPoint(new cc.Point(0.5, 0.5));
        cookieObj.setGridPosition(row,col);
        this._objectMatrix[row][col] = cookieObj;

        var gridX = this._gridMatrix[row][col].getPosition().x;
        var gridY = this._gridMatrix[row][col].getPosition().y;

        var duration = PATTERN_FALL_TIME + ((row / GRID_MAX_ROW) * PATTERN_FALL_TIME);
        var posMultiplier = 1.0 + (row / GRID_MAX_ROW * 2.0);

        this._objectMatrix[row][col].setPosition(gridX, gridY + 400.0 * posMultiplier); //we offset to animate movement
        this._objectMatrix[row][col].moveTo(duration, this._gridMatrix[row][col].getPosition());
        this._gridContainer.addChild(this._objectMatrix[row][col]);
    },


    isPatternValid: function(row, col, targetType) {
        if(this._objectMatrix[row][col] && this._objectMatrix[row][col].getCookieState() == GameEnums.CookieState.NORMAL) {
            var cookieType = this._objectMatrix[row][col].getCookieType();
            //check if it matches the target type
            if(cookieType == targetType)
                return true;
        }
        else {
            return false;
        }
    },

    isTargetPowerUp: function(targetType){
        if(targetType != null) {
            if(/*!this._hasFoundPowerUp &&*/ (targetType == GameEnums.CookieType.POWERUP_COOKIE_CUTTER || targetType == GameEnums.CookieType.POWERUP_MILK ||
                targetType == GameEnums.CookieType.POWERUP_HANDS)) {
                //this._hasFoundPowerUp = true;
                return true;
            }
            else
                return false;
        }

        return false;
    },

    isPatternPowerUp: function(row, col, count) {

        if(this._objectMatrix[row][col] != null
            && this._objectMatrix[row][col].getCookieState() == GameEnums.CookieState.NORMAL
            && !this._hasFoundPowerUp) {

            var cookieType = this._objectMatrix[row][col].getCookieType();

            if(cookieType == GameEnums.CookieType.POWERUP_COOKIE_CUTTER || cookieType == GameEnums.CookieType.POWERUP_MILK ||
                cookieType == GameEnums.CookieType.POWERUP_HANDS) {
                //console.log("PATTERN IS POWERUP! " +cookieType);
                this._hasFoundPowerUp = true; //flag to stop consecutive powerups from counting
                return true;
            }
            else {
                return false;
            }
        }
        return false;
    },

    //called if count > 0 and less than maximum, which denotes that a wild card is in between the cookie
    isPatternWildCard: function(row, col, count) {
         if(this._objectMatrix[row][col] != null && this._objectMatrix[row][col].getCookieState() == GameEnums.CookieState.NORMAL
             && count >= 1 && count < MINIMUM_CONTINUOUS_COUNT - 1) {
             var cookieType = this._objectMatrix[row][col].getCookieType();
             if(cookieType == GameEnums.CookieType.WILDCARD_ICECREAM || cookieType == GameEnums.CookieType.WILDCARD_WHIPCREAM) {
                 return true;
             }
         }

        return false;
    },

    //checks for any consecutive patterns
    getResultByPoint: function(row, col, matrixMark) {

        if(this._objectMatrix[row][col] == null) {
            return false;
        }


       var targetType = this._objectMatrix[row][col].getCookieType();
       if(targetType == null || this._objectMatrix[row][col].getCookieState() != GameEnums.CookieState.NORMAL) {
           return false;
       }

        var result = false;
        var count = 1;
        var start = col;
        var end = col;

        var i = col - 1;
        this._hasFoundPowerUp = false;

        //automatically counts. we change target type to next valid type
        if(this.isTargetPowerUp(targetType) && i >= 0) {
                if(this._objectMatrix[row][i] != null) {
                    console.log("Pattern is powerup! Case 1 " +targetType);
                    targetType = this._objectMatrix[row][i].getCookieType();
                    count++;
                    i--;
                }
        }

        //check to the left
        while(i >= 0) {

            if(this.isPatternValid(row, i, targetType) || this.isPatternWildCard(row, i, count) || this.isPatternPowerUp(row, i, count)) {
                count++;
                start = i;
            }
            else {
                break;
            }
            i--;
        }


        i = col + 1;
        //this._hasFoundPowerUp = false;

        //automatically counts. we change target type to next valid type
        if(this.isTargetPowerUp(targetType) && i < GRID_MAX_COLUMN) {
                if(this._objectMatrix[row][i] != null) {
                    console.log("Pattern is powerup! Case 2 " +targetType);
                    targetType = this._objectMatrix[row][i].getCookieType();
                    count++;
                    i++;
                }
        }
        //check to the right
        while(i < GRID_MAX_COLUMN) {
            if(this.isPatternValid(row, i, targetType) || this.isPatternWildCard(row, i, count) || this.isPatternPowerUp(row, i, count)) {
                count++;
                end = i;
            }
            else {
                break;
            }
            i++;
        }

        if(count >= MINIMUM_CONTINUOUS_COUNT) {
            for(var i = start; i <= end; i++) {
                if(matrixMark[row][i] == null) {
                    matrixMark[row][i] = 1; //1 denotes that it's a candidate for clearing
                }
            }
            result = true;
        }

        count = 1;
        start = row;
        i = row - 1;
        this._hasFoundPowerUp = false;

        //automatically counts. we change target type to next valid type
        if(this.isTargetPowerUp(targetType) && i >= 0) {
            if(this._objectMatrix[i][col] != null) {
                console.log("Pattern is powerup! Case 3 " +targetType);
                targetType = this._objectMatrix[i][col].getCookieType();
                count++;
                i--;
            }

        }
        //check upward
        while(i >= 0) {
            if(this.isPatternValid(i , col, targetType) || this.isPatternWildCard(i, col, count) || this.isPatternPowerUp(i, col, count)) {
                count++;
                start = i;
            }
            else {
                break;
            }
            i--;
        }

        end = row;
        i = row + 1;
        //this._hasFoundPowerUp = false;

        //automatically counts. we change target type to next valid type
        if(this.isTargetPowerUp(targetType) && i < GRID_MAX_ROW) {
            if(this._objectMatrix[row][i] != null) {
                console.log("Pattern is powerup! Case 4 " +targetType);
                targetType = this._objectMatrix[i][col].getCookieType();
                count++;
                i++;
            }
        }

        //check downward
        while(i < GRID_MAX_ROW) {
            if(this.isPatternValid(i, col, targetType) || this.isPatternWildCard(i, col, count) || this.isPatternPowerUp(i, col, count)) {
                count++;
                end = i;
            }
            else {
                break;
            }
            i++;
        }

        if(count >= MINIMUM_CONTINUOUS_COUNT) {
            for(var i = start; i <= end; i++) {
                if(matrixMark[i][col] == null) {
                    matrixMark[i][col] = 1; //1 denotes that it's a candidate for clearing
                }
            }
            result = true;
        }

        this._hasFoundPowerUp = false;
        return result;
    },


    clearSomePatterns: function(matrixMark) {
        var tally = 0;
        var hasFoundPos = false;
        this._destroyBatchTally++;

        GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.PERFORMING_MATCH);

        for(var row = 0; row < GRID_MAX_ROW; row++) {

            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                if(this._objectMatrix[row][col] == null ||
                        this._objectMatrix[row][col].getCookieState() != GameEnums.CookieState.NORMAL) {
                    continue;
                }

                if(matrixMark[row][col] == 1) { //one means candidate for clearing
                    //destroy pattern
                    PowerUpsHandler.getInstance().addPowerUpQty(this._objectMatrix[row][col].getCookieType());
                    this._objectMatrix[row][col].destroy();
                    this._objectMatrix[row][col].setRemoveBatchIndex(this._destroyBatchTally);

                    if(!hasFoundPos) {
                        ComboDetector.getInstance().setComboPos(this._objectMatrix[row][col].getPosition().x, this._objectMatrix[row][col].getPosition().y);
                        hasFoundPos = true;
                    }
                    tally++;
                    if(tally >= MAX_TALLY_MATCH) {
                        ScoreManager.getInstance().updateScore(tally);
                        console.log("Tally count reached more than " +MAX_TALLY_MATCH+ ". Tally is: " +tally+ " Counting score");
                        tally = 0;
                    }

                }

            }
        }

        ScoreManager.getInstance().updateScore(tally);


        this._gridContainer.runAction(cc.Sequence.create(cc.DelayTime.create(PATTERN_CLEAR_TIME),cc.CallFunc.create(
            this.onClearFinish.bind(this),this,this._destroyBatchTally)));

        return tally;
    },

    onClearFinish: function(pnode, removeIndex) {
        var removeBatchIndex = removeIndex;
        var row, col;

        for(col = 0; col < GRID_MAX_COLUMN && removeBatchIndex; col++) {
            for(row = GRID_MAX_ROW - 1; row >= 0; row--) {
                if((this._objectMatrix[row][col] != null && this._objectMatrix[row][col] != CookieObject.dummyObject)
                    && this._objectMatrix[row][col].getRemoveBatchIndex() == removeBatchIndex) {
                    this._gridContainer.removeChild(this._objectMatrix[row][col], true);
                    this._objectMatrix[row][col] = null;
                }
            }
        }

        this.processGravity();
        this.createCookiesAfterFall();

        this._isPerformingClearing = false;
        this._gridContainer.runAction(cc.Sequence.create(cc.DelayTime.create(0.65),
            cc.CallFunc.create(this.detectAnyMatches.bind(this),this)));
    },

    processGravity: function() {
        for(var col = 0; col < GRID_MAX_COLUMN; col++) {
            for(var row = 0; row < GRID_MAX_ROW; row++) {

                if(this._objectMatrix[row][col] == null
                    && this._gridMatrix[row][col].getGridType() == GameEnums.GridType.NORMAL) {
                    var notnull_r = -1;

                    for(var n = row + 1; n < GRID_MAX_ROW; n++) {
                        if(this._objectMatrix[n][col] != null && this._objectMatrix[n][col] != CookieObject.dummyObject) {
                            notnull_r = n;
                            break;
                        }
                    }

                    if(notnull_r != -1) {
                        if(this._objectMatrix[notnull_r][col].getCookieState() != GameEnums.CookieState.NORMAL) {
                            row = GRID_MAX_ROW;
                            break;
                        }

                        var duration = (notnull_r - row) * PATTERN_GRAVITY_TIME;
                        this._objectMatrix[notnull_r][col].moveTo(duration, this._gridMatrix[row][col].getPosition());
                        this._objectMatrix[row][col] = this._objectMatrix[notnull_r][col];
                        this._objectMatrix[row][col].setGridPosition(row, col);
                        this._objectMatrix[notnull_r][col] = null;
                    }
                }
            }
        }
    },

    createCookiesAfterFall: function() {
        for(var col = 0; col < GRID_MAX_COLUMN; col++) {
            for(var row = GRID_MAX_ROW - 1; row >=0; row--) {
                if(this._objectMatrix[row][col] == null) {
                    this.createOneGridObject(row,col);
                }
                else {
                    break;
                }
            }
        }
    },

    detectAnyMatches: function() {

        if(this._isPerformingClearing) {
            return;
        }

        var matrixMark = MatrixCreator.createArray(GRID_MAX_ROW, GRID_MAX_COLUMN);
        this._isPerformingClearing = true;

        for(var col = 0; col < GRID_MAX_COLUMN; col++) {
            for(var row = 0; row < GRID_MAX_ROW; row++) {
                this.getResultByPoint(row, col, matrixMark);
            }
        }

        if(this.clearSomePatterns(matrixMark) == 0) {
            var result = true;
            //finished finding matches
            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                for(var row = 0; row < GRID_MAX_ROW; row++) {
                    if(this._gridMatrix[row][col].getGridType() == GameEnums.GridType.NORMAL &&
                        (this._objectMatrix[row][col] == null ||
                            this._objectMatrix[row][col].getCookieState() != GameEnums.CookieState.NORMAL)) {
                        result = false;
                        //console.log("Row: " +row+ " Col: " +col+ "  has resulted to false " + this._objectMatrix[row][col]);
                    }
                }
            }

            if(result) {
                //report result here if moves are gone
                this._destroyBatchTally = 0;
                this._hasFoundPowerUp = false;
                ComboDetector.getInstance().reset();

                if(!ScoreManager.getInstance().hasMovesLeft()) {
                    gNotification.postNotification(Notifications.MSG_OUT_OF_MOVES, this);
                    GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.END_OF_GAME);
                }
                /*else if(ScoreManager.getInstance().hasReachedTargetScore()) {
                    gNotification.postNotification(Notifications.MSG_REACHED_TARGET_SCORE, this);
                    GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.END_OF_GAME);
                }*/
                else {
                    GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.AWAITING_INPUT);
                    this._isPerformingClearing = false;
                    this.excludeDeadlock();
                }
            }
        }
    },

    excludeDeadlock: function() {
        if(this._gridVerifier.hasSolution() == false && !this._hasNotifiedDeadlock
            && GameStateTracker.getInstance().getCurrentGameState() == GameStateTracker.GameState.AWAITING_INPUT) {
            this._hasNotifiedDeadlock = true;

            GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.EXCLUDING_DEADLOCK);
            gNotification.postNotification(Notifications.MSG_DEADLOCK_REACHED);
            var delayFunc = new cc.DelayTime.create(DeadlockPrompt.ANIMATION_TIME + DeadlockPrompt.SHOW_TIME + DeadlockPrompt.HIDING_TIME);
            var callFunc = new cc.CallFunc.create(this.performExclusion.bind(this), this);
            this._gridContainer.runAction(cc.Sequence.create(delayFunc, callFunc));
            console.log("DEADLOCK!!");
        }
    },

    performExclusion: function() {

        for(var row = 0; row < GRID_MAX_ROW; row++) {
            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                this._gridContainer.removeChild(this._objectMatrix[row][col], true);
                this.createOneGridObject(row, col);
            }
        }

        this._hasNotifiedDeadlock = false;
        this._gridContainer.stopAllActions();
        this._gridContainer.runAction(cc.Sequence.create(cc.DelayTime.create(PATTERN_FALL_TIME+0.1),
            cc.CallFunc.create(this.detectAnyMatches.bind(this),this)));
    },

    onExit: function() {
        this.unscheduleAllCallbacks();
        alert("Exiting");
    }
});
