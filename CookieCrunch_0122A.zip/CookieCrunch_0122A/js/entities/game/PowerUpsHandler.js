/**
 * Handles the powerups behavior
 * Created by neil.delgallego on 1/15/14.
 */

var PowerUpsHandler = cc.Class.extend({

    _matchGridHandler: null,
    _sharedInstance: null,

    _milkQty: 5,
    _cookieCutterQty: 5,
    _handsQty: 5,

    _hasSelectedPowerUp: false,
    _powerUpSelected: null,

    ctor: function() {

    },

    reset: function() {
        this._milkQty = 5;
        this._cookieCutterQty = 5;
        this._handsQty = 5;

        this._hasSelectedPowerUp = false;
        this._powerUpSelected = null;
    },

    assignMatchGridHandler: function(gridHandler) {
        this._matchGridHandler = gridHandler;
    },

    //when user clicks the power up, it activates it.
    activatePowerUp: function(powerUpType) {
        this._hasSelectedPowerUp = true;
        this._powerUpSelected = powerUpType;
    },

    //deactivates the powerup, if user clicks on the power up button again.
    deactivatePowerUp: function() {
        this._hasSelectedPowerUp = false;
        this._powerUpSelected = null;
    },

    hasPowerUpActive: function() {
        return this._hasSelectedPowerUp;
    },

    getSelectedPowerUp: function() {
        return this._powerUpSelected;
    },

    addPowerUpQty: function(powerUpType) {
        switch(powerUpType) {
            case GameEnums.CookieType.POWERUP_MILK: this._milkQty++; break;
            case GameEnums.CookieType.POWERUP_COOKIE_CUTTER: this._cookieCutterQty++; break;
            case GameEnums.CookieType.POWERUP_HANDS: this._handsQty++; break;
            default: break;
        }

        gNotification.postNotification(Notifications.MSG_ADDED_POWERUP);
    },

    getQuantityOfPowerUp: function(powerUpType) {
        switch(powerUpType) {
            case GameEnums.CookieType.POWERUP_MILK: return this._milkQty;
            case GameEnums.CookieType.POWERUP_COOKIE_CUTTER: return this._cookieCutterQty;
            case GameEnums.CookieType.POWERUP_HANDS: return this._handsQty;
        }
    },

    //after tapping a cookie, we consume the powerup. This is called directly by the hands powerup.
    consumePowerUp: function(cookieClicked) {
        switch(this._powerUpSelected) {
            case GameEnums.CookieType.POWERUP_MILK:
                this.processMilkPowerUp(cookieClicked);
                break;
            case GameEnums.CookieType.POWERUP_COOKIE_CUTTER:
                this.processCookieCutter(cookieClicked);
                break;
            case GameEnums.CookieType.POWERUP_HANDS:
                this.processHands();
                break;
        }

        gNotification.postNotification(Notifications.MSG_CONSUMED_POWERUP);
        this.deactivatePowerUp();
    },

    processMilkPowerUp: function(cookieClicked) {

        this._milkQty--;

        var objectMatrix = this._matchGridHandler.getObjectMatrix();
        var matrixMark = MatrixCreator.createArray(GRID_MAX_ROW, GRID_MAX_COLUMN);

        var cookieType = cookieClicked.getCookieType();

        for(var row = 0; row < GRID_MAX_ROW; row++) {
            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                if(objectMatrix[row][col] != null && objectMatrix[row][col].getCookieType() == cookieType) {
                    matrixMark[row][col] = 1; //marked for deletion
                }
                else {
                    matrixMark[row][col] = 0;
                }
            }
        }

        //actual clearing of said cookies
        this._matchGridHandler.clearSomePatterns(matrixMark);
    },

    processCookieCutter: function(cookieClicked) {
        this._cookieCutterQty--;

        var objectMatrix = this._matchGridHandler.getObjectMatrix();
        var matrixMark = MatrixCreator.createArray(GRID_MAX_ROW, GRID_MAX_COLUMN);

        for(var row = 0; row < GRID_MAX_ROW; row++) {
            for(var col = 0; col < GRID_MAX_COLUMN; col++) {
                if(objectMatrix[row][col] != null && objectMatrix[row][col] == cookieClicked) {
                    matrixMark[row][col] = 1; //marked for deletion
                }
                else {
                    matrixMark[row][col] = 0;
                }
            }
        }

        //actual clearing of said cookies
        this._matchGridHandler.clearSomePatterns(matrixMark);
        ScoreManager.getInstance().updateScore(3); //force call of update score as cookie cutter treats as a 3 match
    },

    processHands: function() {
        this._handsQty--;
        ScoreManager.getInstance().addMoves(3);
    },

    //processes the cookie object if its a powerup upon clearing
    processPatternPowerUp: function(cookieType) {

        if(cookieType !=  GameEnums.CookieType.POWERUP_COOKIE_CUTTER || cookieType != GameEnums.CookieType.POWERUP_HANDS ||
            cookieType != GameEnums.CookieType.POWERUP_MILK) {
            return;
        }

        console.log("adding powerup quantity of " +cookieType);
        this.addPowerUpQty(cookieType);
    }

});

PowerUpsHandler.getInstance = function() {
    if(PowerUpsHandler._sharedInstance == null) {
        PowerUpsHandler._sharedInstance = new PowerUpsHandler();
    }

    return PowerUpsHandler._sharedInstance;
}


