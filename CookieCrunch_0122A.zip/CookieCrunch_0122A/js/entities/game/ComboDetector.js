/**
 * Counts the comboes made by the player for consecutive matches
 * Created by neil.delgallego on 1/15/14.
 */

var ComboDetector = cc.Class.extend({

    _sharedInstance: null,
    _totalCombo: 0,
    _comboPos: null,

    ctor: function() {
        this._comboPos = new cc.Point(0,0);
    },

    addCombo: function() {
        if(this._totalCombo < ComboDetector.MAX_COMBO)
            this._totalCombo++;
    },

    setComboPos: function(x, y) {
        this._comboPos = new cc.Point(x,y - ComboDisplayLayer.Y_OFFSET);

        //perform adjustment if any
        if(this._comboPos.x < ComboDisplayLayer.X_MINIMUM) {
            this._comboPos.x = ComboDisplayLayer.X_MINIMUM;
        }

        var screenWidth = ResolutionManager.getInstance().getScreenWidth();
        if(this._comboPos.y > screenWidth - ComboDisplayLayer.Y_MINIMUM) {
            this._comboPos.y = screenWidth - ComboDisplayLayer.Y_MINIMUM;
        }
    },

    getComboPos: function() {
        return this._comboPos;
    },


    getComboMultiplier: function() {
      console.log("Current combo: " +this._totalCombo);
      switch(this._totalCombo) {
          case 2: return 1.2;
          case 3: return 1.3;
          case 4: return 1.4;
          case 5: return 1.5;
          case 6: return 1.6;
          case 7: return 1.7;
          case 8: return 1.8;
          case 9: return 2.0;
          case 10: return 2.5;
          default: return 1.0;
      }
    },

    getCurrentComboCount: function() {
        return this._totalCombo;
    },

    reset: function() {
        this._totalCombo = 0;
    }
});

ComboDetector.getInstance = function() {
    if(ComboDetector._sharedInstance == null) {
        ComboDetector._sharedInstance = new ComboDetector();
    }

    return ComboDetector._sharedInstance;
}

ComboDetector.MAX_COMBO = 10;
