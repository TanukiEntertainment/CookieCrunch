/**
 * Verifies the grid for any possible solutions.
 * Also excludes deadlocks.
 * Marks the hint pattern for the player
 * Created by neil.delgallego on 1/9/14.
 */

var GridVerifier = cc.Class.extend({

    _objectMatrix: null,

    ctor: function(objectMatrix) {
        this._objectMatrix = objectMatrix;
    },

    isSwapEnabled: function(row, col) {

        if(!this.isMatrixEmpty(row,col) && this._objectMatrix[row][col].isSwappingEnabled()) {
            //console.log("Row: " +row+ " Col: " +col);
            this._objectMatrix[row][col].highlight();
            return true;
        }
        else {
            return false;
        }
    },

    isMatrixEmpty: function(row, col) {
        if(this._objectMatrix[row][col] == null) {
            return true;
        }
        else {
            return false;
        }
    },

    hasSolutionForWildCard: function() {

    },

    hasSolution: function() {
        var targetType = 0;

        for(var row = 0; row < GRID_MAX_ROW; row++) {
            for(var col = 0; col < GRID_MAX_COLUMN - 1; col++) {

                if(this.isMatrixEmpty(row,col)) {
                    continue;
                }

                targetType = this._objectMatrix[row][col].getCookieType();
                if(!this.isMatrixEmpty(row,col + 1) && targetType == this._objectMatrix[row][col + 1].getCookieType()) {

                    //  *
                    //**
                    //  *
                    if(row > 0 && col + 2 < GRID_MAX_COLUMN && !this.isMatrixEmpty(row, col + 2) && !this.isMatrixEmpty(row - 1,col + 2) &&
                        this._objectMatrix[row - 1][col + 2].getCookieType() == targetType){
                        if(this.isSwapEnabled(row, col + 2)) {
                            //mark hint pattern
                            console.log("Case 1");
                            return true;
                        }
                        if(this.isSwapEnabled(row - 1, col + 2)) {
                            //mark hint pattern
                            console.log("Case 2");
                            return true;
                        }
                    }

                    if(row + 1 < GRID_MAX_ROW && col + 2 < GRID_MAX_COLUMN && !this.isMatrixEmpty(row, col + 2) && !this.isMatrixEmpty(row + 1,col + 2) &&
                        this._objectMatrix[row + 1][col + 2].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row, col + 2)) {
                            //mark hint pattern
                            console.log("Case 3");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 1, col + 2)) {
                            //mark hint pattern
                            console.log("Case 4");
                            return true;
                        }
                    }

                    //*
                    // **
                    //*
                    if(row > 0 && col > 0 && !this.isMatrixEmpty(row, col - 1) && !this.isMatrixEmpty(row - 1,col - 1) &&
                        this._objectMatrix[row - 1][col - 1].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row, col - 1)) {
                            //mark hint pattern
                            console.log("Case 5");
                            return true;
                        }
                        if(this.isSwapEnabled(row - 1, col - 1)){
                            //mark hint pattern
                            console.log("Case 6");
                            return true;
                        }
                    }

                    if(row + 1 < GRID_MAX_ROW && col > 0 && !this.isMatrixEmpty(row, col - 1) && !this.isMatrixEmpty(row + 1,col - 1)
                        && this._objectMatrix[row + 1][col - 1].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row, col - 1)) {
                            //mark hint pattern
                            console.log("Case 7");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 1, col - 1)) {
                            //mark hint pattern
                            console.log("Case 8");
                            return true;
                        }
                    }

                    //*-**-*
                    if(col - 2 >= 0 && !this.isMatrixEmpty(row, col - 1) && !this.isMatrixEmpty(row,col - 2)
                        && this._objectMatrix[row][col - 2].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row, col - 2)) {
                            //mark hint pattern
                            console.log("Case 9");
                            return true;
                        }
                        if(this.isSwapEnabled(row, col - 1)) {
                            //mark hint pattern
                            console.log("Case 10");
                            return true;
                        }
                    }

                    if(col + 3 < GRID_MAX_COLUMN && !this.isMatrixEmpty(row, col + 2) && !this.isMatrixEmpty(row,col + 3)
                        && this._objectMatrix[row][col +3].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row, col +3)) {
                            //mark hint pattern
                           console.log("Case 11");
                            return true;
                        }
                        if(this.isSwapEnabled(row, col + 2)) {
                            //mark hint pattern
                            console.log("Case 12");
                            return true;
                        }
                    }
                }
            }

            // x x |  x
            //  x  | x x
            for (var col = 0; col < GRID_MAX_COLUMN - 2; col++){

                if(this.isMatrixEmpty(row,col)) {
                    continue;
                }

                targetType = this._objectMatrix[row][col].getCookieType();
                if(!this.isMatrixEmpty(row,col + 2) && targetType == this._objectMatrix[row][col + 2].getCookieType()) {
                    if(row > 0 && !this.isMatrixEmpty(row, col + 1) && !this.isMatrixEmpty(row - 1,col + 1)
                        && targetType == this._objectMatrix[row - 1][col + 1].getCookieType()) {
                        if(this.isSwapEnabled(row - 1, col + 1)) {
                            //mark hint pattern
                            console.log("Case 13");
                            return true;
                        }
                        if(this.isSwapEnabled(row, col + 1)) {
                            //mark hint pattern
                            console.log("Case 14");
                            return true;
                        }
                    }

                    if(row + 1 < GRID_MAX_ROW && !this.isMatrixEmpty(row, col + 1) && !this.isMatrixEmpty(row + 1,col + 1)
                        && targetType == this._objectMatrix[row + 1][col + 1].getCookieType()) {
                        if(this.isSwapEnabled(row + 1, col + 1)) {
                            //mark hint pattern
                            console.log("Case 15");
                            return true;
                        }
                        if(this.isSwapEnabled(row, col + 1)) {
                            //mark hint pattern
                            console.log("Case 16");
                            return true;
                        }
                    }
                }
            }
        }
    //---------------------------------next solutions --------------------------------------------

        //start checking by row
        for(var col = 0; col < GRID_MAX_COLUMN; col++) {
            for(var row = 0; row < GRID_MAX_ROW - 1; row++) {

                if(this.isMatrixEmpty(row,col)) {
                    continue;
                }

                targetType = this._objectMatrix[row][col].getCookieType();
                if(!this.isMatrixEmpty(row + 1,col) && targetType == this._objectMatrix[row + 1][col].getCookieType()) {
                    // ? ?
                    //  x
                    //  x
                    if(col > 0 && row + 2 < GRID_MAX_ROW && !this.isMatrixEmpty(row + 2, col) && !this.isMatrixEmpty(row + 2,col - 1)
                        && this._objectMatrix[row + 2][col - 1].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row + 2, col - 1)) {
                            //mark hint pattern
                            console.log("Case 17");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 2, col)) {
                            //mark hint pattern
                            console.log("Case 18");
                            return true;
                        }
                    }

                    if(col + 1 < GRID_MAX_COLUMN && row + 2 < GRID_MAX_ROW && !this.isMatrixEmpty(row + 2, col) && !this.isMatrixEmpty(row + 2,col + 1)
                        && this._objectMatrix[row + 2][col + 1].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row + 2, col + 1)) {
                            //mark hint pattern
                            console.log("Case 19");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 2, col)) {
                            //mark hint pattern
                            console.log("Case 20");
                            return true;
                        }
                    }

                    //  x
                    //  x
                    // ? ?
                    if(col > 0 && row > 0 && !this.isMatrixEmpty(row - 1, col) && !this.isMatrixEmpty(row - 1,col - 1)
                        && this._objectMatrix[row - 1][col - 1].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row - 1, col - 1)) {
                            //mark hint pattern
                            console.log("Case 21");
                            return true;
                        }
                        if(this.isSwapEnabled(row - 1, col)) {
                            //mark hint pattern
                            console.log("Case 22");
                            return true;
                        }
                    }
                    if(col + 1 < GRID_MAX_COLUMN && row > 0 && !this.isMatrixEmpty(row - 1, col) && !this.isMatrixEmpty(row - 1,col + 1)
                        && this._objectMatrix[row - 1][col + 1].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row - 1, col + 1)) {
                            //mark hint pattern
                            console.log("Case 23");
                            return true;
                        }
                        if(this.isSwapEnabled(row - 1, col)) {
                            //mark hint pattern
                            console.log("Case 24");
                            return true;
                        }
                    }

                    //* ** *
                    if(row - 2 >= 0 && !this.isMatrixEmpty(row - 1, col) && !this.isMatrixEmpty(row - 2,col)
                        && this._objectMatrix[row - 2][col].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row - 2, col)) {
                            //mark hint pattern
                            console.log("Case 25");
                            return true;
                        }
                        if(this.isSwapEnabled(row - 1, col)) {
                            //mark hint pattern
                            console.log("Case 26");
                            return true;
                        }
                    }

                    if(row + 3 < GRID_MAX_ROW && !this.isMatrixEmpty(row + 2, col) && !this.isMatrixEmpty(row + 3,col)
                        && this._objectMatrix[row + 3][col].getCookieType() == targetType) {
                        if(this.isSwapEnabled(row + 3, col)) {
                            //mark hint pattern
                            console.log("Case 27");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 2, col)) {
                            //mark hint pattern
                            console.log("Case 28");
                            return true;
                        }
                    }
                }
            }

            //  x | x
            // x  |  x
            //  x | x
            for(var row = 0; row < GRID_MAX_ROW - 2; row++) {

                if(this._objectMatrix[row][col] == null) {
                    continue;
                }

                targetType = this._objectMatrix[row][col].getCookieType();
                if(!this.isMatrixEmpty(row + 2,col)
                    && targetType == this._objectMatrix[row + 2][col].getCookieType()) {
                    if(col > 0 && !this.isMatrixEmpty(row + 1, col) && !this.isMatrixEmpty(row + 1,col - 1)
                        && targetType == this._objectMatrix[row + 1][col - 1].getCookieType()) {
                        if(this.isSwapEnabled(row + 1, col - 1)) {
                            //mark hint pattern
                            console.log("Case 29");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 1, col)) {
                            //mark hint pattern
                            console.log("Case 30");
                            return true;
                        }
                    }

                    if(col + 1 < GRID_MAX_COLUMN &&!this.isMatrixEmpty(row + 1, col) && !this.isMatrixEmpty(row + 1,col + 1)
                        && targetType == this._objectMatrix[row + 1][col + 1].getCookieType()) {
                        if(this.isSwapEnabled(row + 1, col + 1)) {
                            //mark hint pattern
                            console.log("Case 31");
                            return true;
                        }
                        if(this.isSwapEnabled(row + 1, col)) {
                            //mark hint pattern
                            console.log("Case 32");
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
});
