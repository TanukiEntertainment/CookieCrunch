/**
 * Handles the creation of larger cookies if a wildcard match has been detected
 * Created by neil.delgallego on 1/14/14.
 */

var CookieSandwichCreator = cc.Class.extend({
    _objectMatrix: null,
    _gridMatrix: null,
    _gridVerifier: null,
    _gridContainer: null,

    ctor: function(objectMatrix, gridMatrix, gridVerifier, gridContainer) {
        this._objectMatrix = objectMatrix;
        this._gridMatrix = gridMatrix;
        this._gridVerifier = gridVerifier;
        this._gridContainer = gridContainer;
    },

    isWildCard: function(cookieType) {
        if(cookieType == GameEnums.CookieType.WILDCARD_ICECREAM || cookieType == GameEnums.CookieType.WILDCARD_WHIPCREAM) {
            return true;
        }
        else {
            return false;
        }
    },

    createOneScaledGridObject: function(cookieType, row, col, scale) {
        var cookieObj = new CookieObject(cookieType);
        cookieObj.setAnchorPoint(new cc.Point(0.5, 0.5));
        cookieObj.setGridPosition(row,col);
        cookieObj.setScale(scale, scale);

        this._objectMatrix[row][col] = cookieObj;

        var gridX = this._gridMatrix[row][col].getPosition().x;
        var gridY = this._gridMatrix[row][col].getPosition().y;

        //this._objectMatrix[row][col].setPosition(gridX, gridY); //we offset to animate movement
        this.findValidSpaceForFour(cookieObj, row, col);
        this._gridContainer.addChild(this._objectMatrix[row][col]);
    },


    //finds valid spaces for four tiles
    findValidSpaceForFour: function(cookieObj, row, col) {
        var result = false;
        var quadrant;

        //initial grid tile as top left
        if(BoundsChecker.isWithinBounds(row, col + 1) && BoundsChecker.isWithinBounds(row + 1, col)
            && BoundsChecker.isWithinBounds(row + 1, col + 1)) {
            //check if these tiles are occupied, cookies can be crumbled here
            if(!this._gridVerifier.isMatrixEmpty(row, col + 1) && !this._gridVerifier.isMatrixEmpty(row + 1, col)
                && !this._gridVerifier.isMatrixEmpty(row + 1, col + 1)) {
                    result = true;
                    quadrant = CookieSandwichCreator.GridOriginQuadrant.QUADRANT_THREE;

                //add as occupied space of the same cookie, so we crumble the cookies occupied
                this._objectMatrix[row][col + 1].destroy();
                this._objectMatrix[row + 1][col].destroy();
                this._objectMatrix[row + 1][col + 1].destroy();

                this._objectMatrix[row][col + 1] = null;
                this._objectMatrix[row + 1][col] = null;
                this._objectMatrix[row + 1][col + 1] = null;
            }
        }

        //check if initial grid tile is a valid top right
        else if(BoundsChecker.isWithinBounds(row - 1, col) && BoundsChecker.isWithinBounds(row, col + 1)
            && BoundsChecker.isWithinBounds(row - 1, col + 1)) {
            //check if these tiles are occupied, cookies can be crumbled here
            if(!this._gridVerifier.isMatrixEmpty(row - 1, col) && !this._gridVerifier.isMatrixEmpty(row, col + 1)
                && !this._gridVerifier.isMatrixEmpty(row - 1, col + 1)) {
                result = true;
                quadrant = CookieSandwichCreator.GridOriginQuadrant.QUADRANT_FOUR;

                //add as occupied space of the same cookie, so we crumble the cookies occupied
                this._objectMatrix[row - 1][col].destroy();
                this._objectMatrix[row][col + 1].destroy();
                this._objectMatrix[row - 1][col + 1].destroy();

                this._objectMatrix[row - 1][col] = CookieObject.dummyObject;
                this._objectMatrix[row][col + 1] = CookieObject.dummyObject;
                this._objectMatrix[row - 1][col + 1] = CookieObject.dummyObject;
            }
        }

        //check if initial grid tile is a valid bottom left
        else if(BoundsChecker.isWithinBounds(row, col + 1) && BoundsChecker.isWithinBounds(row - 1, col)
            && BoundsChecker.isWithinBounds(row + 1, col - 1)) {
            //check if these tiles are occupied, cookies can be crumbled here
            if(!this._gridVerifier.isMatrixEmpty(row, col + 1) && !this._gridVerifier.isMatrixEmpty(row - 1, col)
                && !this._gridVerifier.isMatrixEmpty(row + 1, col - 1)) {
                result = true;
                quadrant = CookieSandwichCreator.GridOriginQuadrant.QUADRANT_ONE;

                //add as occupied space of the same cookie, so we crumble the cookies occupied
                this._objectMatrix[row][col + 1].destroy();
                this._objectMatrix[row - 1][col].destroy();
                this._objectMatrix[row + 1][col - 1].destroy();

                this._objectMatrix[row][col + 1] = CookieObject.dummyObject;
                this._objectMatrix[row - 1][col] = CookieObject.dummyObject;
                this._objectMatrix[row + 1][col - 1] = CookieObject.dummyObject;
            }
        }

        //check if initial grid tile is a valid bottom right
        else if(BoundsChecker.isWithinBounds(row - 1, col) && BoundsChecker.isWithinBounds(row, col - 1)
            && BoundsChecker.isWithinBounds(row - 1, col - 1)) {
            //check if these tiles are occupied, cookies can be crumbled here
            if(!this._gridVerifier.isMatrixEmpty(row - 1, col) && !this._gridVerifier.isMatrixEmpty(row, col - 1)
                && !this._gridVerifier.isMatrixEmpty(row - 1, col - 1)) {
                result = true;
                quadrant = CookieSandwichCreator.GridOriginQuadrant.QUADRANT_TWO;

                //add as occupied space of the same cookie, so we crumble the cookies occupied
                this._objectMatrix[row - 1][col].destroy();
                this._objectMatrix[row][col - 1].destroy();
                this._objectMatrix[row - 1][col - 1].destroy();

                this._objectMatrix[row - 1][col] = CookieObject.dummyObject;
                this._objectMatrix[row][col - 1] = CookieObject.dummyObject
                this._objectMatrix[row - 1][col - 1] = CookieObject.dummyObject;

            }
        }


        if(result) {
            var posX = this._gridMatrix[row][col].getPosition().x;
            var posY = this._gridMatrix[row][col].getPosition().y;

            console.log("QUADRANT: " + quadrant);
            if(quadrant == CookieSandwichCreator.GridOriginQuadrant.QUADRANT_ONE) {
                posX += this._gridMatrix[row][col].getContentSize().width / 2;
                posY -= this._gridMatrix[row][col].getContentSize().height / 2;
            }

            else if(quadrant == CookieSandwichCreator.GridOriginQuadrant.QUADRANT_TWO) {
                posX -= this._gridMatrix[row][col].getContentSize().width / 2;
                posY += this._gridMatrix[row][col].getContentSize().height / 2;
            }
            else if(quadrant == CookieSandwichCreator.GridOriginQuadrant.QUADRANT_THREE) {
                posX += this._gridMatrix[row][col].getContentSize().width / 2;
                posY += this._gridMatrix[row][col].getContentSize().height / 2;
            }

            else if(quadrant == CookieSandwichCreator.GridOriginQuadrant.QUADRANT_FOUR) {
                posX -= this._gridMatrix[row][col].getContentSize().width / 2;
                posY -= this._gridMatrix[row][col].getContentSize().height / 2;
            }

            this._objectMatrix[row][col].setPosition(posX, posY); //we offset to animate movement
        }



    },
    findCookieTypeToCreate: function(row, col) {

        if(BoundsChecker.isWithinBounds(row - 1, col) && this._objectMatrix[row - 1][col] != null) {
            return this._objectMatrix[row - 1][col].getCookieType();
        }
        else if(BoundsChecker.isWithinBounds(row + 1, col) && this._objectMatrix[row + 1][col] != null) {
            return this._objectMatrix[row + 1][col].getCookieType();
        }
        else if(BoundsChecker.isWithinBounds(row, col - 1) && this._objectMatrix[row][col - 1] != null) {
            return this._objectMatrix[row][col - 1].getCookieType();
        }
        else if(BoundsChecker.isWithinBounds(row, col + 1) && this._objectMatrix[row][col + 1] != null) {
            return this._objectMatrix[row][col + 1].getCookieType();
        }

    },

    //find some wildcard matches
    processWildCardMatches: function(matrixMark) {

        for(var row = 0 ; row < GRID_MAX_ROW; row++) {
            for(var col = 0; col < GRID_MAX_COLUMN; col++) {

                if(matrixMark[row][col] == 1 && this._objectMatrix[row][col] != null) { //one means candidate for clearing
                    var cookieType = this._objectMatrix[row][col].getCookieType();
                    if(this.isWildCard(cookieType)) {
                        var cookieTypeToCreate = this.findCookieTypeToCreate(row, col);
                            this.createOneScaledGridObject(cookieTypeToCreate, row, col, 2);
                    }
                }
            }

        }
    }

});

CookieSandwichCreator.SizeType = {
    SCALE_OF_2: "2",
    SCALE_OF_3: "3"
};

CookieSandwichCreator.GridOriginQuadrant = {
    QUADRANT_ONE : "1",
    QUADRANT_TWO : "2",
    QUADRANT_THREE: "3",
    QUADRANT_FOUR: "4"

}
