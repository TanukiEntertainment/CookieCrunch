var MatrixCreator = cc.Class.extend({

});

MatrixCreator.createArray = function(arow,acol) {
    var arr = [];
    for (var row=0; row<arow; row++ )
    {
        arr[row] = [];
        for (var col=0; col<acol; col++){
            arr[row][col] = null;
        }
    }
    return arr;
}