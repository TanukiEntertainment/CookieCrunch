/**
 * Contains the list of classes required for this web application to run.
 * When adding new classes, don't forget to put the path to the end of this list
 *
 * Created By: Neil DG
 */
var sceneList = [ 'js/scenes/MainMenuScene.js',
                  'js/scenes/GameScene.js',
                  'js/scenes/MapScene.js'
                ]; //put scenes here

var layerList = ['js/layout/GameView.js',
                 'js/layout/ResultsView.js',
                 'js/layout/MapLayer.js',
                 'js/layout/MainMenuLayer.js',
                 'js/layout/ComboDisplayLayer.js',
                 'js/layout/layout_items/PowerUpButton.js',
                 'js/layout/DeadlockPrompt.js',
                 'js/layout/PauseLayer.js',
                 'js/layout/DialogLayer.js',
                 'js/layout/BackgroundLayer.js']; //put layers here

var entitiesList = ['js/gameplay/EventsManager.js',
                    'js/entities/Rectangle.js',
                    'js/entities/grid/TileSprite.js',
                    'js/entities/GameEnums.js',
                    'js/entities/grid/GridParser.js',
                    'js/entities/LevelManager.js',
                    'js/entities/grid/GridMatrix.js',
                    'js/entities/grid_objects/GridObject.js',
                    'js/entities/grid_objects/CookieObject.js',
                    'js/entities/Notifications.js',
                    'js/entities/game/MatchGridHandler.js',
                    'js/entities/game/GridVerifier.js',
                    'js/entities/game/GameStateTracker.js',
                    'js/entities/ScoreManager.js',
                    'js/entities/game/CookieSandwichCreator.js',
                    'js/entities/game/BoundsChecker.js',
                    'js/entities/DebugKeyboard.js',
                    'js/entities/game/ComboDetector.js',
                    'js/entities/game/PowerUpsHandler.js'] //put entities or models here

var coreList = [
                'js/anino_cocos/AtlasLayer.js',
                'js/anino_cocos/ClickableSprite.js',
                'js/anino_cocos/CocosActionHelper.js',
                'js/anino_cocos/CocosAssetLoader.js',
                'js/anino_cocos/CocosAtlasManager.js',
                'js/anino_cocos/CocosDebugHelper.js',
                'js/anino_cocos/CocosGenericHelper.js',
                'js/anino_cocos/CocosLayout.js',
                'js/anino_cocos/CocosResources.js',
                'js/anino_cocos/CoordsConverter.js',
                'js/anino_cocos/DebugHelper.js',
                'js/anino_cocos/GrabSprite.js',
                'js/anino_cocos/MathUtils.js',
                'js/anino_cocos/ResolutionManager.js',
                'js/utils/MatrixCreator.js']; //put critical classes such as core or framework

var libraryList = ['js/lib/jquery/jquery-1.8.2.min.js',
                   'js/lib/signals/dist/signals.min.js']; //put library classes here


var eventsList = [
       'js/events/EventData.js',
       'js/events/EventDataManager.js'
                 ]