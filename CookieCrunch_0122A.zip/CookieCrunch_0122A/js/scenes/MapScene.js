/**
 * Created by patrick.pamplona on 1/13/14.
 */
var MapScene = cc.Scene.extend
({
    onEnter: function() {
        this._super();

        var layer = new MapLayer();
        layer.init();

        this.addChild(layer);
    }
});