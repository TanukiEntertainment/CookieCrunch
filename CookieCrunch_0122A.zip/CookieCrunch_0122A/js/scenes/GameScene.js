/**
 * Created by neil.delgallego on 1/6/14.
 */



var gNotification = cc.NotificationCenter.getInstance();
var GameLayer = cc.Layer.extend({

    _resourceInstance: null,
    _gridParser: null,
    _gridContainer: null, //the grid container
    _gridMatrix: null, //represents the board matrix
    _objectMatrix: null,    //represents the actual objects in grid
    _firstCheckPattern: null,
    _secondCheckPattern:null,

    //match checking
    _matchGridHandler: null,

    //represents the UI game view
    _gameView: null,
    _resultsView: null,
    _deadlockView: null,
    _comboDisplayLayer: null,
    _bgLayer: null,

    init: function() {
        this._super();

        //setup data
        ScoreManager.getInstance().reset();
        ComboDetector.getInstance().reset();
        PowerUpsHandler.getInstance().reset();
        ScoreManager.getInstance().setScoreValuesForCurrentLevel();

        this.setMouseEnabled(true);
        this.setTouchEnabled(true);
        this.setKeyboardEnabled(true)
        this.loadRequiredAtlases();

        this._resourceInstance = CocosResources.getInstance();

        //create bg layer
        this._bgLayer = new BackgroundLayer();
        this._bgLayer.initializeBG(BackgroundLayer.activeBGType);
        this.addChild(this._bgLayer);

        var afterAction = cc.CallFunc.create(this.onSuccessfulParseGrid, this);
        //load grid and representation matrix
        this._gridMatrix = MatrixCreator.createArray(GRID_MAX_ROW, GRID_MAX_COLUMN);
        this._gridParser = new GridParser();
        this._gridParser.init(this._gridMatrix, afterAction);

        //load object matrix
        this._objectMatrix = MatrixCreator.createArray(GRID_MAX_ROW, GRID_MAX_COLUMN);

        //position the grid container properly
        var screenWidth = ResolutionManager.getInstance().getScreenWidth();
        var screenHeight = ResolutionManager.getInstance().getScreenHeight();
        this._gridParser.parseLevel(LevelManager.getInstance().getCurrentLevel(), this);
        this._gridParser.setPositionOfContainer(screenHeight * 0.08, screenHeight * -0.155);
        this._gridContainer = this._gridParser.getGridContainer();

        this._comboDisplayLayer = new ComboDisplayLayer();
        this.addChild(this._comboDisplayLayer);

        this.parseUIToStage();

        //create notification events for check of pattern and swapping
        gNotification.addObserver(this, this.onCheckPattern.bind(this), Notifications.MSG_CHECK_PATTERN);
        gNotification.addObserver(this, this.onSwapPattern.bind(this), Notifications.MSG_SWAP_PATTERN);

    },

    onKeyDown: function(e) {
        if(cc.KEY.ctrl == e) {
            DebugKeyboard.getInstance().setCheatActive(true);
        }
    },

    onKeyUp: function(e) {
        gNotification.postNotification(Notifications.MSG_COUNTED_COMBO, this);

        if(cc.KEY.ctrl == e) {
            DebugKeyboard.getInstance().setCheatActive(false);
        }
    },

    onExit: function() {
        gNotification.removeAllObservers(this);
        this.removeAllChildren();
        this.unloadAtlases();
    },

    parseUIToStage: function() {
        this._gameView = new GameView(this);
        this.addChild(this._gameView);

        this._resultsView = new ResultsView(this);
        this.addChild(this._resultsView);

        this._deadlockView = new DeadlockPrompt();
        this.addChild(this._deadlockView);
    },

    //executes this after the grid is parsed
    onSuccessfulParseGrid: function() {
        this.runAction(cc.Sequence.create(cc.DelayTime.create(PATTERN_FALL_TIME+0.2),
            cc.CallFunc.create(this.createGridObjectSeq.bind(this))));

    },
    createGridObjectSeq: function() {
        //instantiate match checker
        this._matchGridHandler = new MatchGridHandler(this._gridContainer,this._gridMatrix, this._objectMatrix);
        this._matchGridHandler.createGridObjects();
    },

    loadRequiredAtlases: function() {
        CocosAtlasManager.getInstance().registerAtlasPack('CRUMBLE_EFFECT');
        CocosAtlasManager.getInstance().cacheAtlas('CRUMBLE_EFFECT_0');
        CocosAtlasManager.getInstance().cacheAtlas('GRID_TILES_0');
        CocosAtlasManager.getInstance().cacheAtlas('COOKIE_TYPES_0');
    },

    unloadAtlases: function() {
        CocosAtlasManager.getInstance().uncacheAtlas('CRUMBLE_EFFECT_0');
        CocosAtlasManager.getInstance().uncacheAtlas('GRID_TILES_0');
        CocosAtlasManager.getInstance().uncacheAtlas('COOKIE_TYPES_0');
    },

    //pattern checking
    onCheckPattern: function(gridObject) {
        if(gridObject != null) {

            if(this._firstCheckPattern == null) {
                this._firstCheckPattern = gridObject;
            }
            else {
                this._secondCheckPattern = gridObject;
                if(this._secondCheckPattern == this._firstCheckPattern) {
                    this._secondCheckPattern = null;
                    return;
                }

                var isAdjacent = false;

                if(this._firstCheckPattern.getRow() == this._secondCheckPattern.getRow()) {
                    if (this._firstCheckPattern.getColumn() &&
                        this._firstCheckPattern.getColumn()-1 == this._secondCheckPattern.getColumn())
                        isAdjacent = true;
                    else if (this._firstCheckPattern.getColumn()+1<GRID_MAX_COLUMN &&
                        this._firstCheckPattern.getColumn()+1 == this._secondCheckPattern.getColumn())
                        isAdjacent = true;
                }
                else if (this._firstCheckPattern.getColumn() == this._secondCheckPattern.getColumn()){
                    if(this._firstCheckPattern.getRow()>0 &&
                        this._firstCheckPattern.getRow()-1 == this._secondCheckPattern.getRow())
                        isAdjacent = true;
                    else if(this._firstCheckPattern.getRow()+1<GRID_MAX_ROW &&
                        this._firstCheckPattern.getRow()+1 == this._secondCheckPattern.getRow())
                        isAdjacent = true;
                }

                if(isAdjacent) {
                    //swap two pattern
                    console.log("ADJACENT");
                    this.performActualSwap(this._firstCheckPattern, this._secondCheckPattern, false);
                    this._firstCheckPattern = null;
                    this._secondCheckPattern = null;
                }
                else {
                    this._firstCheckPattern = this._secondCheckPattern;
                    this._secondCheckPattern = null;
                }
            }
        }
    },

    onSwapPattern: function(gridObject) {
        if(gridObject != null) {
            var pFirstCheckPattern = gridObject;

            /*if(this._firstCheckPattern == pFirstCheckPattern) {
                this._firstCheckPattern = null;
            }*/

            if(this._firstCheckPattern == null || this._firstCheckPattern.getCookieState() != GameEnums.CookieState.NORMAL) {
                return;
            }

            var pSecondCheckPattern = null;

            var firstRow = pFirstCheckPattern.getRow();
            var firstCol = pFirstCheckPattern.getColumn();
            switch(pFirstCheckPattern.getSwipeDirection()) {
                case GameEnums.SwipeDirection.LEFT:
                    if(firstCol > 0) {
                        pSecondCheckPattern = this._objectMatrix[firstRow][firstCol - 1];
                    }
                    break;
                case GameEnums.SwipeDirection.RIGHT:
                    if(firstCol + 1 < GRID_MAX_COLUMN) {
                        pSecondCheckPattern = this._objectMatrix[firstRow][firstCol + 1];
                    }
                    break;
                case GameEnums.SwipeDirection.UP:
                    if(firstRow + 1 < GRID_MAX_ROW) {
                        pSecondCheckPattern = this._objectMatrix[firstRow + 1][firstCol];
                    }
                    break;
                case GameEnums.SwipeDirection.DOWN: {
                    if(firstRow > 0) {
                        pSecondCheckPattern = this._objectMatrix[firstRow - 1][firstCol];
                    }
                    break;
                }
                default :
                    this._firstCheckPattern = null;
                    this._secondCheckPattern = null;
                    break;
            }
        }

        if(pSecondCheckPattern != null
                && pSecondCheckPattern.getCookieState() == GameEnums.CookieState.NORMAL) {
            if(this._firstCheckPattern == pSecondCheckPattern) {
                this._firstCheckPattern = null;

            }
            this.performActualSwap(pFirstCheckPattern, pSecondCheckPattern, false);
        }
        else {
            console.log("Second check pattern null!!!");
        }

    },

    performActualSwap: function(firstPattern, secondPattern, recover) {
        var firstRow = firstPattern.getRow();
        var firstCol = firstPattern.getColumn();
        var secondRow = secondPattern.getRow();
        var secondCol = secondPattern.getColumn();

        firstPattern.setSwapPattern(secondPattern);
        secondPattern.setSwapPattern(firstPattern);

        //console.log("First pattern: " +firstPattern.getCookieState()+ "Second pattern: " +secondPattern.getCookieState());
        if(firstPattern.getCookieState() == GameEnums.CookieState.NORMAL && secondPattern.getCookieState() == GameEnums.CookieState.NORMAL) {
            firstPattern.setRecover(recover);
            secondPattern.setRecover(recover);

            firstPattern.swapTo(PATTERN_SWAP_TIME, this._gridMatrix[secondRow][secondCol].getPosition());
            secondPattern.swapTo(PATTERN_SWAP_TIME, this._gridMatrix[firstRow][firstCol].getPosition());

            firstPattern.setGridPosition(secondRow, secondCol);
            secondPattern.setGridPosition(firstRow, firstCol);

            this._objectMatrix[firstRow][firstCol] = secondPattern;
            this._objectMatrix[secondRow][secondCol] = firstPattern;
             this._gridContainer.runAction(cc.Sequence.create(cc.DelayTime.create(PATTERN_SWAP_TIME),
            cc.CallFunc.create(this.onSwapFinish.bind(this),this,firstPattern)));
        }

    },

    onSwapFinish: function(pnode, pattern) {
        var firstPattern = pattern;
        var secondPattern = firstPattern.getSwapPattern();

        firstPattern.setCookieState(GameEnums.CookieState.NORMAL);
        secondPattern.setCookieState(GameEnums.CookieState.NORMAL);

        if(firstPattern.isRecovering()) {
            this._matchGridHandler.onClearFinish(null, null);
        }
        else {

            var matrixMark = MatrixCreator.createArray(GRID_MAX_ROW, GRID_MAX_COLUMN);

            if(this._matchGridHandler.getResultByPoint(firstPattern.getRow(), firstPattern.getColumn(), matrixMark) ||
                this._matchGridHandler.getResultByPoint(secondPattern.getRow(), secondPattern.getColumn(), matrixMark)) {
                this._matchGridHandler.clearSomePatterns(matrixMark);
                ScoreManager.getInstance().deductMoves();
                console.log("Found matches! Clearing patterns!");
            }
            else {
                //unswap
                this.performActualSwap(firstPattern, secondPattern, true);
            }

        }
    }
});

var GameScene = cc.Scene.extend({
    onEnter: function() {
        this._super();

        var layer = new GameLayer();
        layer.init();

        this.addChild(layer);
    }
});
