/**
 * The base class for managing of events for Castle Queen
 * Created by neil.delgallego on 12/13/13.
 */

var EventsManager = cc.Class.extend({
    _sharedInstance: null,

    init: function() {

    }

});

EventsManager.getInstance = function() {
    if(EventsManager._sharedInstance == null) {
        EventsManager._sharedInstance = new EventsManager();
        EventsManager._sharedInstance.init();
    }

    return EventsManager._sharedInstance;
}
