/**
 * Represents a special type of event for Castle Queen
 * Created by neil.delgallego on 12/13/13.
 */

var SpecialEvents = cc.Class.extend({

})
