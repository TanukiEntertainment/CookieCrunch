/**
 * Created by patrick.pamplona on 1/7/14.
 * Handles the events of the game
 */

var EventDataManager = cc.Class.extend({
    _sharedInstance: null,

    //signal when an event is dispatched
    eventSignal: null,

    //Event/Dialog ids
    _eventIds: null,

    //Current Event Data
    currentEventData: null,

    init: function()
    {
        this.eventSignal = new signals.Signal();
        this._eventIds   = [
                               EventDataManager.EVT_FIRSTTIME,
                               EventDataManager.EVT_FIRSTMATCH,
                               EventDataManager.EVT_COOKIESANDWICH,
                               EventDataManager.EVT_POWERUPS,
                               EventDataManager.EVT_POWERUPSUSED
                           ];
    },

    hasEventData: function(evtId)
    {
        return this._eventIds.indexOf(evtId) != -1;
    },

    getCurrentEventData: function()
    {
        return this.currentEventData;
    },

    dispatchEventWithId : function(eventId)
    {
        var idx = this._eventIds.indexOf(eventId);
        if(idx == -1) return;
        this._eventIds.splice(idx, 1);

        //create the event
        this.currentEventData = new EventData();
        this.currentEventData.init(eventId);
        this.currentEventData.printEventDetails();

        //dispatch event
        this.eventSignal.dispatch(this.currentEventData);
    },

    //when the event is completed
    onEventComplete : function()
    {
        this.currentEventData = null;
    },

    dispose: function()
    {
        this.eventSignal.removeAll();
        this.currentEventData = null;
    }
});

EventDataManager.getInstance = function() {
    if(EventDataManager._sharedInstance == null){
        EventDataManager._sharedInstance = new EventDataManager();
        EventDataManager._sharedInstance.init();
    }

    return EventDataManager._sharedInstance;
}

EventDataManager.EVT_FIRSTTIME      = "EVT_FIRSTTIME";
EventDataManager.EVT_FIRSTMATCH     = "EVT_FIRSTMATCH";
EventDataManager.EVT_COOKIESANDWICH = "EVT_COOKIESANDWICH";
EventDataManager.EVT_POWERUPS       = "EVT_POWERUPS";
EventDataManager.EVT_POWERUPSUSED   = "EVT_POWERUPSUSED";