/**
 * Created by patrick.pamplona on 1/7/14.
 * Event data containing the asset used for the event, the init parameter and the action parameter
 * This also contains the rewards, texts and their position in the screen
 */
var EventData = cc.Class.extend({
    eventId: null,
    texts: null,

    //set the event properties given the event data
    init : function(evtId)
    {
        this.eventId = evtId;
        var _json = CocosResources.getInstance().getDataResource(evtId);
        this.texts         = _json["texts"];
    },

    getEventId : function()
    {
        return this.eventId;
    },

    getTextAt : function(idx)
    {
        if(this.texts == null || idx >= this.texts.length) return null;
        return this.texts[idx];
    },

    getTextCount : function()
    {
        if(this.texts == null) return 0;
        return this.texts.length;
    },

    //Print the event details for debugging
    printEventDetails : function()
    {
        console.log('\n----------<' + this.eventId + '> EVENT----------\n');

        console.log('TEXTS ' + DebugHelper.arrayToString(this.texts));

        console.log('\n----------<' + this.eventId + '> EVENT----------\n');
    }
});