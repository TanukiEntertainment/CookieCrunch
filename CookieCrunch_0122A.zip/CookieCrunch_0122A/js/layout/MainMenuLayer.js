/**
 * Created by patrick.pamplona on 1/14/14.
 */
var MainMenuLayer = AtlasLayer.extend
({
    layout: null,
    layer: null,

    init: function()
    {
        this._super();
        this.registerAtlas('MAINMENU');
        this.registerAtlas('COMMON');
        return this;
    },

    onEnter:function()
    {
        this._super();

        this.layer = cc.Node.create();
        this.layer.setAnchorPoint(cc.p(0, 1));

        this.layout = new CocosLayout();
        this.layout.parseUI('MAINMENU_LAYOUT', this, this.layer);
        this.addChild(this.layer);

        this.layout.getButton('btn_play').setCallback(this.onPlayClicked.bind(this));
        this.layout.getButton('btn_moregames').setCallback(this.onMoreGamesClicked.bind(this));
        this.createButtonGlow();
    },

    createButtonGlow: function() {
        var playButton = this.layout.getButton('btn_play');
        var overlayAnim = this.createSprite('PNG_COMMON_BTN_LONG_PRESSED');
        overlayAnim.setAnchorPoint(new cc.Point(0,0));
        overlayAnim.setOpacity(0);

        var glowAction = new cc.FadeTo.create(1.0, 150);
        var glowActionReverse = new cc.FadeTo.create(1.0, 0);
        var glowSequence = new cc.Sequence.create(glowAction, glowActionReverse);

        overlayAnim.runAction(cc.RepeatForever.create(glowSequence));
        playButton.addChild(overlayAnim);
    },

    onPlayClicked: function()
    {
        var scene = new MapScene();
        scene.init();
        cc.Director.getInstance().replaceScene(cc.TransitionFade.create(1, scene));
    },

    onMoreGamesClicked: function() {
        window.open("http://www.zibbo.com/");
    }
});