/**
 * Created by neil.delgallego on 1/13/14.
 */
var ResultsView = AtlasLayer.extend({

    _layoutParser: null,
    _parentLayer: null,
    _resources: null,
    _currentLevel: 0,
    _scoreLabel: null,
    _actualScore: null,
    _yourbestLabel: null,
    _actualBest: null,
    _levelLabel: null,
    _resultLabel: null,
    _moveInAction: null,

    _origPos: null,
    ctor: function(parentLayer) {
        this._super();
        this._resources = CocosResources.getInstance();
        this._parentLayer = parentLayer;

        this.registerAtlas('HUD_ATLAS');
        this.registerAtlas('COMMON');
        this._currentLevel = LevelManager.getInstance().getCurrentLevel();

        //show results view when out of moves has been dispatched
        gNotification.addObserver(this, this.processResult.bind(this), Notifications.MSG_OUT_OF_MOVES);
    },

    onEnter: function() {
        this._super();
        this.parseUI();

        //this.processResult(null);
    },

    onExit: function() {
        gNotification.removeObserver(this, Notifications.MSG_OUT_OF_MOVES);
    },

    parseUI: function() {

        this._layoutParser = new CocosLayout();
        this._layoutParser.parseUI('RESULT_POPUP_LAYOUT',this, this);

        var screenWidth = ResolutionManager.getInstance().getScreenWidth();
        var screenHeight = ResolutionManager.getInstance().getScreenHeight();

        var txt = CocosResources.getInstance().getLocString("RESULT_SCORE");

        var popup = this._layoutParser.getImage('IMG_POPUP_BG');
        this._scoreLabel = cc.LabelTTF.create(txt, 'DejaVuCondensedBold', 48);
        this._scoreLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this._scoreLabel.setFontFillColor(cc.c3b(103, 60, 21));
        this._scoreLabel.setAnchorPoint(cc.p(0, 1));
        this._scoreLabel.setPosition(cc.p(120, popup.getContentSize().height * 0.9));
        popup.addChild(this._scoreLabel);

        this._actualScore = cc.LabelTTF.create('0 ', 'DejaVu', 48);
        this._actualScore.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this._actualScore.setFontFillColor(cc.c3b(103, 60, 21));
        this._actualScore.setAnchorPoint(cc.p(0, 1));
        this._actualScore.setPosition(cc.p(this._scoreLabel.getPosition().x + this._scoreLabel.getContentSize().width + 20, popup.getContentSize().height * 0.9));
        popup.addChild(this._actualScore);

        txt = CocosResources.getInstance().getLocString("RESULT_YOURBEST");
        this._yourbestLabel = cc.LabelTTF.create(txt, 'DejaVuCondensedBold', 48);
        this._yourbestLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this._yourbestLabel.setFontFillColor(cc.c3b(103, 60, 21));
        this._yourbestLabel.setAnchorPoint(cc.p(0, 1));
        this._yourbestLabel.setPosition(cc.p(140, this._scoreLabel.getPosition().y - this._scoreLabel.getContentSize().height - 20));
        popup.addChild(this._yourbestLabel);

        this._actualBest = cc.LabelTTF.create('0 ', 'DejaVu', 48);
        this._actualBest.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this._actualBest.setFontFillColor(cc.c3b(103, 60, 21));
        this._actualBest.setAnchorPoint(cc.p(0, 1));
        this._actualBest.setPosition(cc.p(popup.getContentSize().width * 0.5, this._yourbestLabel.getPosition().y - this._yourbestLabel.getContentSize().height - 20));
        popup.addChild(this._actualBest);

        txt = CocosResources.getInstance().getLocString("MAP_LEVEL");
        this._levelLabel = cc.LabelTTF.create(txt + this._currentLevel, 'DejaVuCondensedBold', 64);
        this._levelLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this._levelLabel.setFontFillColor(cc.c3b(103, 60, 21));
        this._levelLabel.enableStroke(cc.c3b(255, 255, 255), 5);
        this._levelLabel.setAnchorPoint(cc.p(0, 1));
        this._levelLabel.setPosition(cc.p((ResolutionManager.getInstance().getScreenWidth() * 0.5) - (this._levelLabel.getContentSize().width * 0.5), ResolutionManager.getInstance().getScreenHeight() * 0.95));
        this.addChild(this._levelLabel);

        txt = CocosResources.getInstance().getLocString("RESULT_COMPLETE");
        this._resultLabel = cc.LabelTTF.create(txt, 'DejaVuCondensedBold', 54);
        this._resultLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this._resultLabel.setFontFillColor(cc.c3b(103, 60, 21));
        this._resultLabel.enableStroke(cc.c3b(255, 255, 255), 5);
        this._resultLabel.setAnchorPoint(cc.p(0, 1));
        this._resultLabel.setPosition(cc.p((ResolutionManager.getInstance().getScreenWidth() * 0.5) - (this._resultLabel.getContentSize().width * 0.5), ResolutionManager.getInstance().getScreenHeight() * 0.875));
        this.addChild(this._resultLabel);


        this._origPos = new cc.Point(this.getPosition().x, this.getPosition().y - 500);
        var addedPt = new cc.Point(0, 500);
        this._moveInAction = new cc.MoveBy.create(ResultsView.ANIMATION_DURATION, addedPt);

        //hide layout temporarily
        this.setVisible(false);
        this.setupButtons();
    },

    setupButtons: function() {
        var restartBtn = this._layoutParser.getButton('BTN_REPLAY');
        restartBtn.setCallback(this.onRestartButtonClicked.bind(this));

        var nextLevelBtn = this._layoutParser.getButton('BTN_NEXT_LEVEL');
        nextLevelBtn.setCallback(this.onNextLevelButtonClicked.bind(this));
    },

    onRestartButtonClicked: function() {
        var data = LevelManager.getInstance().getLevelData(this._currentLevel);
        data.setScore(ScoreManager.getInstance()._currentScore);

        this.setVisible(false);

        var scene = new GameScene();
        cc.Director.getInstance().replaceScene(cc.TransitionFade.create(1, scene));
    },

    onNextLevelButtonClicked: function() {
        var data = LevelManager.getInstance().getLevelData(this._currentLevel);
        data.setScore(ScoreManager.getInstance()._currentScore);

        LevelManager.getInstance().unlockNextLevel();
        var currentLevel = LevelManager.getInstance().getCurrentLevel();
        currentLevel++;
        LevelManager.getInstance().setLevel(currentLevel);

       this.onRestartButtonClicked();
    },

    processResult: function(sender) {

        if(ScoreManager.getInstance().hasReachedTargetScore()) {
            this.processShowAnimation();
            this.showSuccessfulResult();
        }
        else {
            this.processShowAnimation();
            this.showFailedResult();
        }
    },

    processShowAnimation: function() {
        this.setPosition(this._origPos);
        this.setVisible(true);
        this.runAction(cc.EaseElasticOut.create(this._moveInAction));
    },

    onResultsShow: function() {
        if(ScoreManager.getInstance().hasReachedTargetScore()) {
            this.showSuccessfulResult();
        }
        else {
            this.showFailedResult();
        }
    },

    showFailedResult: function() {
        this.setVisible(true);

        var nextBtn = this._layoutParser.getButton('BTN_NEXT_LEVEL');
        nextBtn.setVisible(false);

        gNotification.removeObserver(this, Notifications.MSG_OUT_OF_MOVES);

        this.updateResultDetails(true);
    },

    showSuccessfulResult: function() {
        this.setVisible(true);

        //we hide next button if its the last level
        if(LevelManager.getInstance().getCurrentLevel() == LevelManager.MAX_LEVEL) {
            var nextBtn = this._layoutParser.getButton('BTN_NEXT_LEVEL');
            nextBtn.setVisible(false);
        }
        gNotification.removeObserver(this, Notifications.MSG_REACHED_TARGET_SCORE);
        gNotification.removeObserver(this, Notifications.MSG_OUT_OF_MOVES);

        this.updateResultDetails(false);
    },

    updateResultDetails: function(failed)
    {
        var data = LevelManager.getInstance().getLevelData(this._currentLevel);
        var score = ScoreManager.getInstance()._currentScore;

        var best = data.getScore();
        if(best == 0 || score > best) best = score;

        this._actualScore.setString(score);
        this._actualBest.setString(best);

        var popup = this._layoutParser.getImage('IMG_POPUP_BG');
        var _y = this._yourbestLabel.getPosition().y - this._yourbestLabel.getContentSize().height - 20;
        this._actualBest.setPosition(cc.p((popup.getContentSize().width * 0.5) - (this._actualBest.getContentSize().width * 0.5), _y));

        if(failed)
        {
            var txt = CocosResources.getInstance().getLocString("RESULT_FAILED");
            this._resultLabel.setString(txt);
            this._resultLabel.setPosition(cc.p((ResolutionManager.getInstance().getScreenWidth() * 0.5) - (this._resultLabel.getContentSize().width * 0.5), ResolutionManager.getInstance().getScreenHeight() * 0.875));
        }
    }
});

ResultsView.ANIMATION_DURATION = 4.0;