/**
 * Created by patrick.pamplona on 1/20/14.
 */
var PauseLayer = AtlasLayer.extend({

    layout : null,
    layer  : null,

    init: function()
    {
        this.registerAtlas("COMMON");
    },

    //catch the touches on the top level to avoid touches of the button below the layer unless the touch hits a button
    onTouchBegan: function(touch, event)
    {
        var btns = [
                      this.layout.getButton('btn_resume'),
                      this.layout.getButton('btn_levels'),
                      this.layout.getButton('btn_moregames'),
                      this.layout.getButton('btn_sounds'),
                      this.layout.getButton('btn_zibbo')
                   ];

        for(var b = 0; b < btns.length; b++)
        {
            var btn = btns[b];
            var box = btn.getBoundingBoxToWorld();
            if(cc.rectContainsPoint(box, touch.getLocation()))
            {
                return false;
            }
        }

        return true;
    },

    onEnter: function()
    {
        this._super();
        var darkBg = cc.DrawNode.create();
        darkBg.drawPoly([cc.p(0, 0), cc.p(0, 1024), cc.p(768, 1024), cc.p(768, 0)], new cc.Color4F(0, 0, 0, 0.5), 0, new cc.Color4F(0, 0, 0, 0));
        this.addChild(darkBg);

        this.layer = cc.Node.create();
        this.layer.setAnchorPoint(cc.p(0, 1));

        this.layout = new CocosLayout();
        this.layout.parseUI('PAUSE_LAYOUT', this, this.layer);
        this.addChild(this.layer);

        CocosGenericHelper.setButtonText(this.layout.getButton('btn_resume'), 'RESUME', 'DejaVuCondensedBold', 32, cc.c3b(150, 70, 22), cc.c3b(255, 255, 255), 2);
        CocosGenericHelper.setButtonText(this.layout.getButton('btn_levels'), 'LEVELS', 'DejaVuCondensedBold', 32, cc.c3b(150, 70, 22), cc.c3b(255, 255, 255), 2);
        CocosGenericHelper.setButtonText(this.layout.getButton('btn_moregames'), 'MORE GAMES', 'DejaVuCondensedBold', 32, cc.c3b(150, 70, 22), cc.c3b(255, 255, 255), 2);

        this.setButtons();
        this.unpauseGame();
    },

    pauseGame: function()
    {
        this.setVisible(true);
        GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.GAME_PAUSED);
        cc.registerTargetedDelegate(-148, true, this);
    },

    unpauseGame: function()
    {
        this.setVisible(false);
        GameStateTracker.getInstance().setGameState(GameStateTracker.GameState.PERFORMING_MATCH);
        cc.unregisterTouchDelegate(this);
    },

    setButtons: function()
    {
        this.layout.getButton('btn_resume').setCallback(this.onResumeClicked.bind(this));
        this.layout.getButton('btn_levels').setCallback(this.onLevelsClicked.bind(this));
        this.layout.getButton('btn_moregames').setCallback(this.onMoreGamesClicked.bind(this));

        this.layout.getButton('btn_sounds').setCallback(this.onSoundsToggled.bind(this));
        this.layout.getButton('btn_zibbo').setCallback(this.onZibboClicked.bind(this));
    },

    onResumeClicked: function()
    {
        this.unpauseGame();
    },

    onLevelsClicked: function()
    {
        this.unpauseGame();
        var scene = new MapScene();
        cc.Director.getInstance().replaceScene(cc.TransitionFade.create(1, scene));
    },

    onMoreGamesClicked: function()
    {
        window.open("http://www.zibbo.com/");
        console.log('more games clicked');
    },

    onSoundsToggled: function()
    {
        console.log('sounds toggled');
    },

    onZibboClicked: function()
    {
        console.log('zibbo clicked');
    },

    onExit: function()
    {
        this._super();
        cc.unregisterTouchDelegate(this);
    }
});