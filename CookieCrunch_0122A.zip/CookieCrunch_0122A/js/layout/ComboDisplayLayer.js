/**
 * All combo texts and animations will be placed in this layer
 * Created by neil.delgallego on 1/15/14.
 */

var ComboDisplayLayer = cc.Layer.extend({

    _comboLabelText: null,
    _comboScoreText: null,
    _resources: null,
    _labelAnimAction: null,
    _scoreAnimAction: null,

    _isAnimating: false,

    ctor: function() {
        this._super();
        this._resources = CocosResources.getInstance();


    },

    onEnter: function() {
        this._super();
        this.initializeTexts();

        gNotification.addObserver(this, this.showComboPrompt.bind(this), Notifications.MSG_COUNTED_COMBO);

    },

    onExit: function() {

    },

    showComboPrompt: function() {
        /*var comboCount = ComboDetector.getInstance().getCurrentComboCount();
        if(comboCount < 2) {
            return;
        }*/

        console.log("Showing combo prompt!");
        this.resetTextPositions(true);
        if(!this._isAnimating && this._comboLabelText.getNumberOfRunningActions() == 0) {
            this._comboLabelText.runAction(this._labelAnimAction);
            this._comboScoreText.runAction(this._scoreAnimAction);
            this._isAnimating = true;
        }
    },

    findCorrespondingLabelText: function() {
        var comboCount = ComboDetector.getInstance().getCurrentComboCount();
        switch(comboCount) {
            case 2: return this._resources.getLocString('COMBO_TWO_STRING');
            case 3: return this._resources.getLocString('COMBO_THREE_STRING');
            case 4: return this._resources.getLocString('COMBO_FOUR_STRING');
            case 5: return this._resources.getLocString('COMBO_FIVE_STRING');
            case 6: return this._resources.getLocString('COMBO_SIX_STRING');
            case 7: return this._resources.getLocString('COMBO_SEVEN_STRING');
            case 8: return this._resources.getLocString('COMBO_EIGHT_STRING');
            case 9: return this._resources.getLocString('COMBO_NINE_STRING');
            case 10: return this._resources.getLocString('COMBO_TEN_STRING');
            default: return "";
        }
    },

    resetTextPositions: function(shouldShow) {
        var screenWidth = ResolutionManager.getInstance().getScreenWidth();
        var screenHeight = ResolutionManager.getInstance().getScreenHeight();

        this._comboLabelText.setString(this.findCorrespondingLabelText());
        this._comboLabelText.setColor(new cc.Color3B(0,255,0));
        this._comboLabelText.setFontSize(55);
        this._comboLabelText.setPosition(ComboDetector.getInstance().getComboPos());
        //this._comboLabelText.setPosition(new cc.Point(screenWidth * 0.5, (screenHeight * 0.5) + 100));
        this._comboLabelText.setVisible(shouldShow);

        this._comboScoreText.setString(ScoreManager.getInstance().getScoreEarned());
        this._comboScoreText.setColor(new cc.Color3B(255,0,0));
        this._comboScoreText.setFontSize(35);
        this._comboScoreText.setPosition(this._comboLabelText.getPosition().x, this._comboLabelText.getPosition().y - 100);
        //this._comboScoreText.setPosition(new cc.Point(screenWidth * 0.5, (screenHeight * 0.5)));
        this._comboScoreText.setVisible(shouldShow);
    },

    onMoveEnd: function() {
        this.resetTextPositions(false);
        this._isAnimating = false;
    },

    initializeTexts: function() {

        this._comboLabelText = new cc.LabelTTF.create("YUMM!");
        this._comboLabelText.setFontName('DejaVuCondensedBold');

        this._comboScoreText = new cc.LabelTTF.create("2000");
        this._comboScoreText.setFontName('DejaVuCondensedBold');

        this.resetTextPositions(false);

        //animation action
        //var addedPt = new cc.Point(this._comboLabelText.getPosition().x, this._comboLabelText.getPosition().y + 200);
        //var addedPt2 = new cc.Point(this._comboLabelText.getPosition().x, this._comboLabelText.getPosition().y + 50);

        var addedPt = new cc.Point(0, 50);
        var addedPt2 = new cc.Point(0, 25);
        this._labelAnimAction = new cc.Sequence.create(cc.MoveBy.create(ComboDisplayLayer.ANIMATE_DURATION,addedPt),
            cc.CallFunc.create(this.onMoveEnd.bind(this),this));
        this._scoreAnimAction = new cc.Sequence.create(cc.MoveBy.create(ComboDisplayLayer.ANIMATE_DURATION,addedPt2),
            cc.CallFunc.create(this.onMoveEnd.bind(this),this));

        this.addChild(this._comboLabelText);
        this.addChild(this._comboScoreText);


    }
});

ComboDisplayLayer.ANIMATE_DURATION = 2.0;
ComboDisplayLayer.Y_OFFSET = 50;
ComboDisplayLayer.X_MINIMUM = 150;
ComboDisplayLayer.Y_MINIMUM = 20;
