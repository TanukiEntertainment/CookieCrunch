/**
 * Created by neil.delgallego on 1/20/14.
 */
var DeadlockPrompt = AtlasLayer.extend({

    _layoutParser: null,
    _resources: null,

    ctor: function() {
        this._super();
        this._resources = CocosResources.getInstance();

        this.registerAtlas('HUD_ATLAS');
    },

    onEnter: function() {
        this._super();
        this.parseUI();

        gNotification.addObserver(this, this.showDeadlockPrompt.bind(this),Notifications.MSG_DEADLOCK_REACHED);
        //gNotification.postNotification(Notifications.MSG_DEADLOCK_REACHED);
    },

    onExit: function() {
        gNotification.removeObserver(Notifications.MSG_DEADLOCK_REACHED);
    },

    parseUI: function() {
        this._layoutParser = new CocosLayout();
        this._layoutParser.parseUI('DEADLOCK_PROMPT_LAYOUT', this, this);

        var promptBG = this._layoutParser.getImage('IMG_POPUP_SMALL');
        var width = promptBG.getContentSize().width;
        var height = promptBG.getContentSize().height;

        //create texts
        var deadlockText = new cc.LabelTTF.create(this._resources.getLocString('DEADLOCK_STRING'), 'DejaVu', 45);
        deadlockText.setColor(new cc.Color3B(150, 70, 22));
        deadlockText.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
        deadlockText.setPosition(width * 0.5, (height * 0.5) - 50);
        deadlockText.setDimensions(new cc.Size(width, height));
        promptBG.addChild(deadlockText);


        this.setPosition(0, -DeadlockPrompt.Y_OFFSET);
        this.setVisible(false);
    },

    //shows the deadlock prompt then hides it after a certain time
    showDeadlockPrompt: function() {
        var addedPt = new cc.Point(0, DeadlockPrompt.Y_OFFSET);
        var animationShow = new cc.MoveBy.create(DeadlockPrompt.ANIMATION_TIME, addedPt);
        animationShow = new cc.EaseElasticOut.create(animationShow);

        var delayTimeFunc = new cc.DelayTime.create(DeadlockPrompt.SHOW_TIME);
        var callFunc = new cc.CallFunc.create(this.hideDeadlockPrompt.bind(this));

        this.runAction(cc.Sequence.create(animationShow, callFunc));
        this.setVisible(true);
    },

    hideDeadlockPrompt: function() {
        this.setVisible(false);

        var addedPt = new cc.Point(0, -DeadlockPrompt.Y_OFFSET);
        var animationShow = new cc.MoveBy.create(DeadlockPrompt.HIDING_TIME, addedPt);
        animationShow = new cc.EaseBackOut.create(animationShow);
        var callFunc = new cc.CallFunc.create(this.onFinishedHideAnim.bind(this));

        this.runAction(cc.Sequence.create(animationShow, callFunc));
    },

    onFinishedHideAnim: function() {
        this.setVisible(false);
    }
});

DeadlockPrompt.Y_OFFSET = 400;
DeadlockPrompt.ANIMATION_TIME = 1.5;
DeadlockPrompt.HIDING_TIME = 0.0;
DeadlockPrompt.SHOW_TIME = 0.0;