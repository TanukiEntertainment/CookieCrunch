/**
 * Created by patrick.pamplona on 1/20/14.
 */
var DialogLayer = AtlasLayer.extend({

    layout : null,
    layer  : null,

    evtData: null,
    currentTxt: -1,

    dialog: null,

    init: function()
    {
        this.registerAtlas("EVTS_AND_DIALOG");
    },

    onTouchBegan: function(touch, event)
    {
        cc.unregisterTouchDelegate(this);

        if(this.currentTxt == -1 || this.evtData == null || (this.evtData != null && this.currentTxt + 1 >= this.evtData.getTextCount()))
        {
            this.currentTxt = -1;
            this.evtData = null;
            this.setVisible(false);
        }
        else if(this.evtData != null)
        {
            console.log('showing next dialog text');
            this.currentTxt++;
            this.showDialog(CocosResources.getInstance().getLocString(this.evtData.getTextAt(this.currentTxt)));
        }

        return true;
    },

    onEnter: function()
    {
        this._super();
        var darkBg = cc.DrawNode.create();
        darkBg.drawPoly([cc.p(0, 0), cc.p(0, 1024), cc.p(768, 1024), cc.p(768, 0)], new cc.Color4F(0, 0, 0, 0.5), 0, new cc.Color4F(0, 0, 0, 0));
        this.addChild(darkBg);

        this.layer = cc.Node.create();
        this.layer.setAnchorPoint(cc.p(0, 1));

        this.layout = new CocosLayout();
        this.layout.parseUI('DIALOG_LAYOUT', this, this.layer);
        this.addChild(this.layer);

        this.setVisible(false);
    },

    dispatchDialogSequence: function(evt)
    {
        this.evtData = evt;
        this.currentTxt = 0;
        this.showDialog(CocosResources.getInstance().getLocString(this.evtData.getTextAt(this.currentTxt)));
    },

    showDialog: function(text)
    {
        var dialogBox = this.layout.getImage('dialog');

        if(this.dialog != null)
        {
            dialogBox.removeChild(this.dialog);
        }

        this.dialog = CocosGenericHelper.setButtonText(dialogBox, text, 'DejavuCondensed', 28, cc.c3b(150, 70, 22), null, null);
        this.dialog.setDimensions(new cc.Size(dialogBox.getContentSize().width * 0.8, dialogBox.getContentSize().height * 0.8));
        this.dialog.setPosition(cc.p(this.dialog.getPosition().x + LEFT_MARGIN, this.dialog.getPosition().y - TOP_MARGIN));

        cc.registerTargetedDelegate(-200, true, this);
        this.setVisible(true);
    },

    onExit: function()
    {
        this._super();
    }
});

var LEFT_MARGIN = 15;
var TOP_MARGIN  = 35;