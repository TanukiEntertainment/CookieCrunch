/**
 * Represents the power up button
 * Created by neil.delgallego on 1/16/14.
 */

var PowerUpButton = cc.Class.extend({

    _powerUpBtn: null,
    _powerUpQtyText: null,
    _powerUpType: null,

    ctor: function(powerUpBtn, powerUpType) {
        this._powerUpBtn = powerUpBtn;
        this._powerUpType = powerUpType;
        this.initializeTextDisplay();

        gNotification.addObserver(this, this.onConsumedPowerUp.bind(this), Notifications.MSG_CONSUMED_POWERUP);
        gNotification.addObserver(this, this.onAddedPowerUpQty.bind(this), Notifications.MSG_ADDED_POWERUP);

        this._powerUpBtn.setCallback(this.onButtonPressed.bind(this));
    },

    initializeTextDisplay: function() {
        //create quantity text for milkBtn
        this._powerUpQtyText = new cc.LabelTTF.create("0");
        this._powerUpQtyText.setFontName('DejaVuCondensedBold');
        this._powerUpQtyText.setColor(new cc.Color3B(0,255,0));
        this._powerUpQtyText.setFontSize(30);
        this._powerUpQtyText.setPosition(new cc.Point(this._powerUpBtn.getContentSize().width - 20, 20));
        this._powerUpBtn.addChild(this._powerUpQtyText);

        var powerUpsHandler = PowerUpsHandler.getInstance();
        this._powerUpQtyText.setString(powerUpsHandler.getQuantityOfPowerUp(this._powerUpType)); //force update
        this.disableOnZeroQty();
    },

    disableOnZeroQty: function() {
        var powerUpsHandler = PowerUpsHandler.getInstance();
        if(powerUpsHandler.getQuantityOfPowerUp(this._powerUpType) == 0) {
            this._powerUpBtn.setEnabled(false);
        }
        else {
            this._powerUpBtn.setEnabled(true);
        }
    },

    onConsumedPowerUp: function(sender) {
        var powerUpsHandler = PowerUpsHandler.getInstance();
        if(this._powerUpType == powerUpsHandler.getSelectedPowerUp()) {
            this.disableOnZeroQty();
            this._powerUpQtyText.setString(powerUpsHandler.getQuantityOfPowerUp(this._powerUpType));
        }
    },

    onAddedPowerUpQty: function(sender) {
        var powerUpsHandler = PowerUpsHandler.getInstance();
        this.disableOnZeroQty();
        this._powerUpQtyText.setString(powerUpsHandler.getQuantityOfPowerUp(this._powerUpType));
    },

    onButtonPressed: function() {
        var powerUpsHandler = PowerUpsHandler.getInstance();
        if(!powerUpsHandler.hasPowerUpActive()) {
            powerUpsHandler.activatePowerUp(this._powerUpType);

            //we consume hands powerup immediately
            if(this._powerUpType == GameEnums.CookieType.POWERUP_HANDS) {
                powerUpsHandler.consumePowerUp(null);
            }
        }
        else {
            powerUpsHandler.deactivatePowerUp();
        }
    },

    destroy: function() {
        gNotification.removeObserver(this, Notifications.MSG_CONSUMED_POWERUP);
        gNotification.removeObserver(this, Notifications.MSG_ADDED_POWERUP);
    }
})
