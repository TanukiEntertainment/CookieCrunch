/**
 * Represents the game view as a UI layer
 * Created by neil.delgallego on 1/13/14.
 */

var GameView = AtlasLayer.extend({

    _layoutParser: null,
    _parentLayer: null,
    _resources: null,
    _scoremeter: null,

    _milkPowerUpBtn: null,
    _cookiePowerUpBtn: null,
    _handsPowerUpBtn: null,

    dialogLayer: null,
    pauseScreen: null,

    ctor: function(parentLayer)
    {
        this._super();
        this._parentLayer = parentLayer;
        this._resources = CocosResources.getInstance();

        this.registerAtlas('COMMON');
        this.registerAtlas('COOKIE_TYPES');
        this.registerAtlas('HUD_ATLAS');

       // gNotification.addObserver(this, this.onConsumedPowerUp.bind(this), Notifications.MSG_CONSUMED_POWERUP);
    },

    onEnter: function() {
        this._super();
        this.parseUI();

        console.log("On enter");
    },

    onExit: function() {
        this.clearMsgListener();
    },

    parseUI: function() {
        this._layoutParser = new CocosLayout();
        this._layoutParser.parseUI('HUD_LAYOUT',this, this);

        var mainMenuButton = this._layoutParser.getButton('BTN_MENU');
        //add text to menu.
        CocosGenericHelper.setButtonText(mainMenuButton, 'MENU', 'DejaVuCondensedBold', 45, cc.c3b(150, 70, 22), cc.c3b(255, 255, 255), 2);
        mainMenuButton.setCallback(this.onMainMenuClicked.bind(this));

        this.createScorePanelDisplay('IMG_PANEL_BG_1', 'MOVES_STRING');
        this.createScorePanelDisplay('IMG_PANEL_BG_2', 'SCORE_STRING');
        this.createScorePanelDisplay('IMG_PANEL_BG_3', 'TARGET_SCORE_STRING');

        this.setupPowerButtons();

        this._scoremeter = this._layoutParser.getImage('score_progress');
        this._scoremeter.setScaleX(0);

        ScoreManager.getInstance()._scoreUpdateSignal.add(this.updateScoreMeter.bind(this));

        this.pauseScreen = new PauseLayer();
        this.pauseScreen.init();
        this.addChild(this.pauseScreen);

        if(EventDataManager.getInstance().hasEventData(EventDataManager.EVT_FIRSTTIME))
        {
            this.dialogLayer = new DialogLayer();
            this.dialogLayer.init();
            this.addChild(this.dialogLayer);

            EventDataManager.getInstance().eventSignal.add(this.onEventSignal.bind(this));
            EventDataManager.getInstance().dispatchEventWithId(EventDataManager.EVT_FIRSTTIME);
        }
    },

    onEventSignal: function(evtData)
    {
        if(this.dialogLayer != null)
        {
            this.dialogLayer.dispatchDialogSequence(evtData);
        }
    },

    updateScoreMeter: function(score)
    {
        var data = LevelManager.getInstance().getCurrentLevelData();
        if(data != null)
        {
            var ratio = score / data.getTargetScore();
            if(ratio > 1.0) ratio = 1.0;

            this._scoremeter.setScaleX(ratio);
        }
    },

    setupPowerButtons: function() {
        var milkBtn = this._layoutParser.getButton('BTN_POWERUP_1');
        this._milkPowerUpBtn = new PowerUpButton(milkBtn, GameEnums.CookieType.POWERUP_MILK);

        var cookieCutBtn = this._layoutParser.getButton('BTN_POWERUP_2');
        this._cookiePowerUpBtn = new PowerUpButton(cookieCutBtn, GameEnums.CookieType.POWERUP_COOKIE_CUTTER);

        var handsBtn = this._layoutParser.getButton('BTN_POWERUP_3');
        this._handsPowerUpBtn = new PowerUpButton(handsBtn, GameEnums.CookieType.POWERUP_HANDS);
    },


    createScorePanelDisplay: function(stringID, labelStringID) {
        //create moves text
        var movesPanel = this._layoutParser.getImage(stringID);
        var movesText = new cc.LabelTTF.create(this._resources.getLocString(labelStringID));
        movesText.setFontName('DejaVuCondensedBold');
        movesText.setColor(new cc.Color3B(150,70,22));
        movesText.setFontSize(35);
        movesText.setPosition(new cc.Point(movesPanel.getContentSize().width / 2, 90));

        //create move number text
        var movesNumText = new cc.LabelTTF.create("9999");
        movesNumText.setFontName('DejaVu');
        movesNumText.setColor(new cc.Color3B(255,255,255));
        movesNumText.setFontSize(35);
        movesNumText.setPosition(new cc.Point(movesPanel.getContentSize().width / 2, 45));

        movesPanel.addChild(movesText);
        movesPanel.addChild(movesNumText);

        if(stringID == 'IMG_PANEL_BG_1') {
            ScoreManager.getInstance().bindUIText(movesNumText, ScoreManager.UITextKeys.MOVES_UI_TEXT);
        }
        else if(stringID == 'IMG_PANEL_BG_2') {
            ScoreManager.getInstance().bindUIText(movesNumText, ScoreManager.UITextKeys.SCORE_UI_TEXT);
        }
        else if(stringID == 'IMG_PANEL_BG_3') {
            ScoreManager.getInstance().bindUIText(movesNumText, ScoreManager.UITextKeys.TARGET_SCORE_UI_TEXT);
        }

    },

    //call this function prior tos cene transition
    clearMsgListener:function(){
        gNotification.removeObserver(this._parentLayer, Notifications.MSG_CHECK_PATTERN);
        gNotification.removeObserver(this._parentLayer, Notifications.MSG_SWAP_PATTERN);

        this._milkPowerUpBtn.destroy();
        this._cookiePowerUpBtn.destroy();
        this._handsPowerUpBtn.destroy();
    },

    onMainMenuClicked: function()
    {
        //this.clearMsgListener();

        //var scene = new MainMenuScene();
        //cc.Director.getInstance().replaceScene(cc.TransitionFade.create(1, scene));
        this.pauseScreen.pauseGame();
    },

    onExit: function()
    {
        this._super();
        this.removeChild(this.pauseScreen);
    }
});
