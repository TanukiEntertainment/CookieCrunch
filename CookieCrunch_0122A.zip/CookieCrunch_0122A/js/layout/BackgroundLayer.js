/**
 * Refers to the changeable background layer on every game view
 * Created by neil.delgallego on 1/21/14.
 */

var BackgroundLayer = AtlasLayer.extend({

    _resources: null,
    _bgType: null,

    _activeBGSprite: null,
    _isAnimating : false,

    ctor: function() {
        this._super();
        this._resources = CocosResources.getInstance();

        this.registerAtlas('COOKIE_CRUNCH_BG');
    },

    onEnter: function() {
        this._super();
        this._activeBGSprite = this.createSprite(this._bgType);
        this._activeBGSprite.setAnchorPoint(0,0);
        this._activeBGSprite.setPosition(0,0);
        this.addChild(this._activeBGSprite);
    },

    initializeBG: function(backgroundType) {
       this._bgType = backgroundType;
       BackgroundLayer.activeBGType = this._bgType;
    },

    //performs an animation when changing of BG
    changeBG: function(newBGType, direction) {
        var newBGSprite = this.createSprite(newBGType);

        var screenWidth = ResolutionManager.getInstance().getScreenWidth();
        newBGSprite.setAnchorPoint(0,0);
        newBGSprite.setPosition(screenWidth, 0);
        this.addChild(newBGSprite);

        this._activeBGSprite.stopAllActions();
        this._isAnimating = true;
        if(direction == BackgroundLayer.PageDirection.PAGE_RIGHT) {
            var moveIn = new cc.MoveBy.create(BackgroundLayer.SWAP_DURATION, new cc.Point(-screenWidth, 0));
            var moveOut = new cc.MoveBy.create(BackgroundLayer.SWAP_DURATION, new cc.Point(-screenWidth, 0));
            var afterFunc = new cc.CallFunc.create(this.onActionFinished.bind(this), this, newBGSprite);

            moveIn = new cc.EaseSineOut.create(moveIn);
            moveOut = new cc.EaseSineOut.create(moveOut);

            this._activeBGSprite.runAction(cc.Sequence.create(moveOut, afterFunc));
            newBGSprite.runAction(moveIn);
        }
        else {
            newBGSprite.setPosition(-screenWidth, 0);
            var moveIn = new cc.MoveBy.create(BackgroundLayer.SWAP_DURATION, new cc.Point(screenWidth, 0));
            var moveOut = new cc.MoveBy.create(BackgroundLayer.SWAP_DURATION, new cc.Point(screenWidth, 0));
            var afterFunc = new cc.CallFunc.create(this.onActionFinished.bind(this), this, newBGSprite);

            moveIn = new cc.EaseSineOut.create(moveIn);
            moveOut = new cc.EaseSineOut.create(moveOut);

            this._activeBGSprite.runAction(cc.Sequence.create(moveOut, afterFunc));
            newBGSprite.runAction(moveIn);
        }

        this._bgType = newBGType;
        BackgroundLayer.activeBGType = this._bgType;


    },

    isAnimating: function() {
        return this._isAnimating;
    },

    onActionFinished: function(actionNode, newBgSprite) {
        //change sprite active
        this._activeBGSprite.removeFromParent(true);
        this._activeBGSprite = newBgSprite;
        BackgroundLayer.activeBG = this._activeBGSprite;
        this._isAnimating = false;
        console.log("Changing of active BG");
    },

    getBGTypeByIndex: function(index) {
        switch(index) {
            case 1: return BackgroundLayer.BackgroundType.BG_WORLD_1;
            case 2: return BackgroundLayer.BackgroundType.BG_WORLD_2;
            case 3: return BackgroundLayer.BackgroundType.BG_WORLD_3;
            case 4: return BackgroundLayer.BackgroundType.BG_WORLD_4;
        }
    }
});

BackgroundLayer.BackgroundType =
{
    BG_WORLD_1: 'PNG_BG_WORLD_1',
    BG_WORLD_2: 'PNG_BG_WORLD_2',
    BG_WORLD_3: 'PNG_BG_WORLD_3',
    BG_WORLD_4: 'PNG_BG_WORLD_4'
}

BackgroundLayer.PageDirection =
{
    PAGE_LEFT : 'PAGE_LEFT',
    PAGE_RIGHT: 'PAGE_RIGHT'
}

BackgroundLayer.SWAP_DURATION = 1.0;
BackgroundLayer.activeBGType = null; //global access to active BG type for easy access of BG
