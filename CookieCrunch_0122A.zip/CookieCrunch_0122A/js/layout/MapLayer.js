/**
 * Created by patrick.pamplona on 1/13/14.
 */
const LEVELS_PER_PAGE = 12;
const LAST_PAGE = 4;

var MapLayer = AtlasLayer.extend
({
    layout : null,
    layer  : null,

    currentPage        : 1,
    levelSelected      : false,
    levelSelectionText : null,
    levelTargetText    : null,
    levelMovesText     : null,

    levelButtons : [],
    levelTexts   : [],

    _bgLayer: null,

    init: function()
    {
        this._super();
        this.registerAtlas('HUD_ATLAS');
        this.registerAtlas('MAP');

        this.currentPage   = 1;
        this.levelSelected = false;
        this.levelButtons  = [];
        this.levelTexts    = [];

        //initialize BG layer
        this._bgLayer = new BackgroundLayer();
        this._bgLayer.initializeBG(BackgroundLayer.BackgroundType.BG_WORLD_1);



        return this;
    },

    onEnter:function()
    {
        this._super();

        this.addChild(this._bgLayer);

        this.layer = cc.Node.create();
        this.layer.setAnchorPoint(cc.p(0, 1));

        this.layout = new CocosLayout();
        this.layout.parseUI('MAP_LAYOUT', this, this.layer);
        this.addChild(this.layer);

        this.setLayoutButtons();
        this.setLevelButtons();
        this.setLevelLabels();
        this.updatePage();

        this.createButtonGlow();
    },

    createButtonGlow: function() {
        var playButton = this.layout.getButton('btn_play');
        var overlayAnim = this.createSprite('MAP_PLAY_BUTTON_PRESSED');
        overlayAnim.setAnchorPoint(new cc.Point(0,0));
        overlayAnim.setOpacity(0);

        /*var buttonWidth = playButton.getContentSize().width;
        var buttonHeight = playButton.getContentSize().height;

        var playIcon  = this.createSprite('PNG_ICON_PLAY');
        playIcon.setPosition(buttonWidth * 0.5, buttonHeight * 0.5);
        overlayAnim.addChild(playIcon);*/

        var glowAction = new cc.FadeTo.create(1.0, 255);
        var glowActionReverse = new cc.FadeTo.create(1.0, 0);
        var glowSequence = new cc.Sequence.create(glowAction, glowActionReverse);

        overlayAnim.runAction(cc.RepeatForever.create(glowSequence));
        playButton.addChild(overlayAnim);
    },

    onExit: function() {
        this.removeAllChildren();

    },

    setLayoutButtons: function()
    {
        this.layout.getButton("left_arrow").setTag('left');
        this.layout.getButton("right_arrow").setTag('right');
        this.layout.getButton("left_arrow").setScaleX(-1.0);
        this.layout.getButton("left_arrow").setCallback(this.onPageClicked.bind(this));
        this.layout.getButton("right_arrow").setCallback(this.onPageClicked.bind(this));
        this.layout.getButton("btn_play").setCallback(this.onPlayClicked.bind(this));
        this.layout.getButton('BTN_MENU').setCallback(this.onMainMenuClicked.bind(this));

        //add text to menu.
        var menuBtn = this.layout.getButton('BTN_MENU');
        CocosGenericHelper.setButtonText(menuBtn, 'MENU', 'DejaVuCondensedBold', 45, cc.c3b(150, 70, 22), cc.c3b(255, 255, 255), 2);
    },

    setLevelButtons: function()
    {
        var lvlContainer =  this.layout.getImage("layout_indicator");
        lvlContainer.setVisible(false);
        var containerPos = CoordsConverter.convertCoordinates(lvlContainer.getPosition().x, lvlContainer.getPosition().y, 2);

        for(var lvl = 0; lvl < LEVELS_PER_PAGE; lvl++)
        {
            var btn = cc.Node.create();
            this.layout.parseUI('LEVEL_BUTTON', this, btn);
            this.layout.getButton('btn_level').setTag('level_' + (lvl + 1));
            this.addChild(btn);

            var btnBounds = this.layout.getButton('btn_level').getContentSize();

            var btnPos = new cc.p();
            btn.setAnchorPoint(cc.p(0, 1));
            btnPos.x = containerPos.x + ((lvl % 4) * btnBounds.width) + (17 * (lvl % 4));
            btnPos.y = containerPos.y + (Math.floor(lvl / 4) * btnBounds.height) + (17 * Math.floor(lvl / 4));
            btnPos.y = -btnPos.y;

            btn.setPosition(btnPos);

            var levelLabel = cc.LabelTTF.create((lvl + 1).toString(), 'DejaVuCondensed', 64);
            levelLabel.setHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER);
            levelLabel.setFontFillColor(cc.c3b(255, 148, 148));
            levelLabel.enableStroke(cc.c3b(255, 255, 255), 3);
            levelLabel.setAnchorPoint(cc.p(0, 1));

            var textPos = CoordsConverter.convertCoordinates(btnPos.x, -btnPos.y, 2);
            textPos.x += btnBounds.width * 0.5 - levelLabel.getContentSize().width * 0.5;
            textPos.y -= btnBounds.height * 0.5 - levelLabel.getContentSize().height * 0.75;
            levelLabel.setPosition(textPos);
            this.addChild(levelLabel);

            this.levelTexts.push(levelLabel);

            var buttonObject = {'btn_level'  : this.layout.getButton('btn_level'),
                                'heart_1' : this.layout.getButton('heart_1'),
                                'heart_2' : this.layout.getButton('heart_2'),
                                'heart_3' : this.layout.getButton('heart_3'),
                                'lock' : this.layout.getButton('lock')};
            this.levelButtons.push(buttonObject);
        }
    },

    onPageClicked: function(sender)
    {
        var tag = sender.getTag();
        if(tag == 'left' && this.currentPage > 1 && !this._bgLayer.isAnimating()) {
            this.currentPage--;
            this._bgLayer.changeBG(this._bgLayer.getBGTypeByIndex(this.currentPage), BackgroundLayer.PageDirection.PAGE_LEFT);
        }
        else if(tag == 'right' && this.currentPage < LAST_PAGE && !this._bgLayer.isAnimating()) {
            this.currentPage++;
            this._bgLayer.changeBG(this._bgLayer.getBGTypeByIndex(this.currentPage), BackgroundLayer.PageDirection.PAGE_RIGHT);
        }

        this.updatePage();
    },

    updatePage: function()
    {
        this.layout.getButton('left_arrow').setVisible(this.currentPage > 1);
        this.layout.getButton('right_arrow').setVisible(this.currentPage < LAST_PAGE);



        var pageStart = ((this.currentPage - 1) * LEVELS_PER_PAGE);

        for(var txt = 0; txt < this.levelTexts.length; txt++)
        {
            var levelLabel = this.levelTexts[txt];

            var textPos = levelLabel.getPosition();
            textPos.x += levelLabel.getContentSize().width * 0.5;
            textPos.y += levelLabel.getContentSize().height * 0.75;

            levelLabel.setString((pageStart + (txt + 1)).toString());
            textPos.x -= levelLabel.getContentSize().width * 0.5;
            textPos.y -= levelLabel.getContentSize().height * 0.75;
            levelLabel.setPosition(textPos);
        }

        for(var btn = 0; btn < this.levelButtons.length; btn++)
        {
            var obj = this.levelButtons[btn];
            var lvlData = LevelManager.getInstance().getLevelData((btn + 1) + pageStart);
            if(lvlData == null || lvlData.isLocked())
            {
                obj['heart_1'].setVisible(false);
                obj['heart_2'].setVisible(false);
                obj['heart_3'].setVisible(false);
                obj['lock'].setVisible(true);
                obj['btn_level'].setCallback(null);
            }
            else
            {
                obj['heart_1'].setVisible(true);
                obj['heart_2'].setVisible(true);
                obj['heart_3'].setVisible(true);
                obj['btn_level'].setCallback(this.onLevelSelected.bind(this));
                obj['lock'].setVisible(false);

                for(var heart = 1; heart <= lvlData.getHeartRating(); heart++)
                {
                    var heartSprite = obj['heart_' + heart];
                    heartSprite.setNormalImage(this.createSprite('MAP_HEART'));
                    heartSprite.setSelectedImage(this.createSprite('MAP_HEART'));
                    heartSprite.setDisabledImage(this.createSprite('MAP_HEART'));
                }
            }
        }
    },

    setLevelLabels: function()
    {
        var bottomDetails = this.layout.getImage('level_details');

        var txt = CocosResources.getInstance().getLocString("MAP_LEVEL");
        this.levelSelectionText = cc.LabelTTF.create(txt, 'DejaVuCondensedBold', 64);
        this.levelSelectionText.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this.levelSelectionText.setFontFillColor(cc.c3b(103, 60, 21));
        this.levelSelectionText.enableStroke(cc.c3b(255, 255, 255), 3);
        this.levelSelectionText.setAnchorPoint(cc.p(0, 1));
        this.levelSelectionText.setPosition(cc.p(50, 240));
        this.levelSelectionText.setVisible(false);

        txt = CocosResources.getInstance().getLocString("MAP_TARGET");
        this.levelTargetText = cc.LabelTTF.create(txt, 'DejaVu', 36);
        this.levelTargetText.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this.levelTargetText.setFontFillColor(cc.c3b(103, 60, 21));
        this.levelTargetText.setAnchorPoint(cc.p(0, 1));
        this.levelTargetText.setPosition(cc.p(50, 170));
        this.levelTargetText.setVisible(false);

        txt = CocosResources.getInstance().getLocString("MAP_MOVES");
        this.levelMovesText = cc.LabelTTF.create(txt, 'DejaVu', 36);
        this.levelMovesText.setHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT);
        this.levelMovesText.setFontFillColor(cc.c3b(103, 60, 21));
        this.levelMovesText.setAnchorPoint(cc.p(0, 1));
        this.levelMovesText.setPosition(cc.p(50, 125));
        this.levelMovesText.setVisible(false);

        bottomDetails.addChild(this.levelSelectionText);
        bottomDetails.addChild(this.levelTargetText);
        bottomDetails.addChild(this.levelMovesText);
    },

    onPlayClicked: function()
    {
        //a level must be selected first
        if(!this.levelSelected) return;
        var scene = new GameScene();
        cc.Director.getInstance().replaceScene(cc.TransitionFade.create(1, scene));
    },

    onMainMenuClicked: function() {
        var scene = new MainMenuScene();
        cc.Director.getInstance().replaceScene(cc.TransitionFade.create(1, scene));
    },

    onLevelSelected: function(sender)
    {
        this.levelSelected = true;

        var lvl = parseInt(sender.getTag().split('_')[1]) + ((this.currentPage - 1) * LEVELS_PER_PAGE);
        LevelManager.getInstance().setLevel(lvl);

        var data = LevelManager.getInstance().getLevelData(lvl);

        this.levelSelectionText.setVisible(true);
        this.levelTargetText.setVisible(data != null);
        this.levelMovesText.setVisible(data != null);

        var txt = CocosResources.getInstance().getLocString("MAP_LEVEL");
        this.levelSelectionText.setString(txt + lvl);
        if(data != null)
        {
            txt = CocosResources.getInstance().getLocString("MAP_TARGET");
            this.levelTargetText.setString(txt + data.getTargetScore());
            txt = CocosResources.getInstance().getLocString("MAP_MOVES");
            this.levelMovesText.setString(txt + data.getMoveCount());
        }
    }
});