/**
 * Created by paolo.suarez on 1/7/14.
 */
var SPRITE_STATE_GRABBED = 0;
var SPRITE_STATE_UNGRABBED = 1;
var GrabSprite  = cc.Sprite.extend({

    _state:SPRITE_STATE_UNGRABBED,
    _tapped:null,
    _moved:false,
    _grabOffset:null,

    init:function(){
      this._tapped = new signals.Signal();

    },

    onEnter:function () {
        //cc.registerTargetedDelegate(0, true, this);
        this._super();
    },

    onExit:function () {
        cc.unregisterTouchDelegate(this);
        this._super();
    },


    onTouchBegan:function (touch, event) {

        cc.log("touched-grabSprite");

        if (this._state != SPRITE_STATE_UNGRABBED) return false;

        var box = this.getBoundingBoxToWorld();

        if(!cc.rectContainsPoint(box,touch.getLocation())){
            return false;
        }

        this._grabOffset = new cc.Point( touch.getLocation().x - this.getPosition().x , touch.getLocation().y - this.getPosition().y );

        cc.log(" " + this.getPosition());
        cc.log('grabOffset: ' + this._grabOffset.x + " " + this._grabOffset.y);

        this._state = SPRITE_STATE_GRABBED;
        this.moved = false;

        return true;
    },

    onTouchMoved:function (touch, event) {

        // If it weren't for the TouchDispatcher, you would need to keep a reference
        // to the touch from touchBegan and check that the current touch is the same
        // as that one.
        // Actually, it would be even more complicated since in the Cocos dispatcher
        // you get Array instead of 1 cc.Touch, so you'd need to loop through the set
        // in each touchXXX method.
        cc.Assert(this._state == SPRITE_STATE_GRABBED, "Paddle - Unexpected state!");

        var touchPoint = touch.getLocation();


        var box = this.getBoundingBoxToWorld();



        if(  (Math.abs((touchPoint.x - this._grabOffset.x) - this.getPositionX()) > 5 || Math.abs((touchPoint.y - this._grabOffset.y) - this.getPositionY()) > 5 )){
            this.moved = true;
        }



        this.setPosition(cc.p(touchPoint.x - this._grabOffset.x, touchPoint.y - this._grabOffset.y));





    },
    onTouchEnded:function (touch, event) {
        cc.Assert(this._state == SPRITE_STATE_GRABBED, "Paddle - Unexpected state!");

        this._state = SPRITE_STATE_UNGRABBED;

        if( this.moved == false ){
            cc.log("tapped!");
            this._tapped.dispatch(this);
        }
    },

    touchDelegateRetain:function () {
    },
    touchDelegateRelease:function () {
    }
});

GrabSprite.createWithSpriteFrameName = function (spriteFrameName) {
    var spriteFrame = null;
    if (typeof(spriteFrameName) == 'string') {
        spriteFrame = cc.SpriteFrameCache.getInstance().getSpriteFrame(spriteFrameName);
        if (!spriteFrame) {
            cc.log("Invalid spriteFrameName: " + spriteFrameName);
            return null;
        }
    } else {
        cc.log("Invalid argument. Expecting string.");
        return null;
    }
    var sprite = new GrabSprite();
    if (sprite && sprite.initWithSpriteFrame(spriteFrame)) {
        return sprite;
    }
    return null;
};