
/**
 * Created by paolo.suarez on 12/13/13.
 */

var CocosLayout = cc.Class.extend({

    _buttonList: [],
    _imageList: [],
    _rectList: [],



    //uinode can be sprite,layer etc..
    parseUI: function(uiKey, atlasLayer,uiNode){
        var uiJSON = CocosResources.getInstance().getUIResource(uiKey);
        return this.onUIJSONLoaded(uiJSON,atlasLayer,uiNode,uiKey);
    },

    createItemSprite: function(atlas,idNormal,idSelected,callback,target){

        var spriteNormal = atlasLayer.createSprite(idNormal);
        var spriteSelected = atlasLayer.createSprite(idSelected);

        var item = cc.MenuItemSprite.create(spriteNormal, spriteSelected, callback, target); //create a menu Item, nothing will happen when clicked
        return item;
    },


    onUIJSONLoaded: function(data,atlasLayer,node,uiKey) {

        //console.log("result: " +JSON.stringify(data));

        if( node == null ) {
            node = atlasLayer;
        }

        var resources = CocosResources.getInstance();
        var rects = [];

        var menuContainer = new cc.Menu.create();
        menuContainer.setPosition(new cc.Point(0,0));


        var sprites = [];
        var menuItems = [];
        var spriteParents = [];
        var buttonParents = [];

        for(var i = 0; i < data.length; i++) {

            var item = data[i];
            var key = item['key'];
            var assetKey = item['assetKey'];

            var angle = item['angle'];
            var scaleX = item['scaleX'];
            var scaleY = item['scaleY'];
            var anchorX = item['pivotX'];
            var anchorY = item['pivotY'];
            var flipX = item['flipX'];
            var parent = item['Parent'];
            var point;

            if( parent == "root"){
                point = CoordsConverter.convertCoordinates(item['x'], item['y'], 2);
            }
            else
            {
                point = new cc.Point(item['x'], item['y']);
            }
            //console.log("ASSET_KEY: " + CocosResources.getInstance().getResource(assetKey));

            if(item['type'] == "image")
            {

                var sprite = null;

                if(assetKey != "DUMMY_NODE_IMG") // add dummy nodes for positioning
                {
                    sprite = atlasLayer.createSprite(assetKey);
                    // node.addChild(sprite);
                    //cc.log("rect: " + sprite.getTextureRect().getWidth());

                    //var dim = sprite.getTextureRect();

                    sprite.setAnchorPoint(new cc.Point(anchorX,anchorY)); //set anchoring to top left corner
                    sprite.setFlippedX(flipX);

                }
                else
                {
                    sprite = new cc.Node();
                    //  node.addChild(sprite);
                }

                sprite.setPosition(point);
                sprite.setRotation( cc.RADIANS_TO_DEGREES( angle ));

                sprite.setScaleX(scaleX);
                sprite.setScaleY(scaleY);

                sprites.push(sprite);

                this._imageList[key] = sprite;
                spriteParents.push(item['Parent']);
            }

            else if(item['type'] == "button") {
                var buttonSources = item['assetKey'].split('|');

                var normalSprite = atlasLayer.createSprite(buttonSources[0]);
                var selectedSprite = atlasLayer.createSprite(buttonSources[1]);

                var menuButton = new cc.MenuItemSprite.create(normalSprite, selectedSprite);

                menuButton.setAnchorPoint(new cc.Point(anchorX,anchorY)); //set anchoring to top left corner
                //menuButton.setFlippedX(flipX);

                menuButton.setPosition(point);
                menuButton.setRotation( cc.RADIANS_TO_DEGREES( angle ));

                menuButton.setScaleX(scaleX);
                menuButton.setScaleY(scaleY);

                menuItems.push(menuButton);
                this._buttonList[key] = menuButton;
                buttonParents.push(item['Parent']);
            }

        }

        //for sprites adding
        for(var i = 0; i < sprites.length; i++){

            var parentId = spriteParents[i];

            var parentNode = null;

            if( parentId == "root"){
                parentNode = node;
                parentNode.addChild(sprites[i]);
            }
            else
            {
                parentNode = this._imageList[parentId];

                var point2 = new cc.Point(  sprites[i].getPosition().x+ parentNode.getAnchorPointInPoints().x,-sprites[i].getPosition().y+parentNode.getAnchorPointInPoints().y);

                sprites[i].setPosition(point2);
                parentNode.addChild(sprites[i]);

                cc.log("parent " + sprites[i].getPositionY());

                // sprites[i].setPosition(new cc.Point(0,0));
            }
        }

        //for menu button adding
        for(var i = 0; i < menuItems.length; i++){

            var parentId = buttonParents[i];
//            console.log("\n\n ---------- " + parentId);
            var parentNode = null;

            if( parentId == "root")
            {
                parentNode = menuContainer;
                parentNode.addChild(menuItems[i]);
//                console.log("ADDING BUTTON TO ROOT");
            }
            else
            {
                parentNode = this._imageList[parentId];

                var point2 = new cc.Point(menuItems[i].getPosition().x+ parentNode.getAnchorPointInPoints().x,
                    -menuItems[i].getPosition().y+parentNode.getAnchorPointInPoints().y);

                menuItems[i].setPosition(point2);
                parentNode.addChild(menuItems[i]);

                cc.log("parent " + menuItems[i].getPositionY());

                // sprites[i].setPosition(new cc.Point(0,0));
            }
        }
        node.addChild(menuContainer);

        delete sprites;

        this._rectList[uiKey] = rects;

        return node;
    },

    getImage: function(key) {
        return this._imageList[key];
    },

    getButton: function(key) {
        return this._buttonList[key];
    },

    getPositionFromImage: function(key) {
        return this.getImage(key).getPosition();
    },

    containsTouchLocation:function (touch,scope) {
        var getPoint = touch.getLocation();

        var uiRects = CocosGenericHelper.getValuesFromDict(this._rectList);
        var uiKeys = CocosGenericHelper.getKeysFromDict(this._rectList);


        for( var i = 0; i < uiRects.length; i++ ){

            if( !CocosGenericHelper.isInArray(scope,uiKeys[i]) ) continue;

            var rects = uiRects[i];
            for( var j = 0; j < rects.length; j++ )
            {
                var rect = rects[i];
                cc.log("getWidth " + rect.x + " " + rect.y);
                if( cc.rectContainsPoint(rect, getPoint) ){
                    return true;
                }
            }
        }

        return false;


    },


    getImagesWithSubString: function(subString) {

        var images = [];

        var keys = CocosGenericHelper.getKeysFromDict( this._imageList );
        var values = CocosGenericHelper.getValuesFromDict( this._imageList );


        for( var i = 0; i < keys.length; i++ ){


            cc.log("KEYS: " + keys[i].indexOf(subString));

            if( keys[i].indexOf(subString) != -1 ){

                cc.log("IMAGES: " + this._imageList[keys[i]]);
                images.push(this._imageList[keys[i]]);
            }
        }
        return images;

    },

    destroy: function() {
        this._buttonList = null;
        this._imageList = null;
    }

});
