/**
 * Converts coordinates to specified quadrant in the cartesian plane.
 * Currently supports quadrant 2 for Cocos2D.
 * Created by neil.delgallego on 12/10/13.
 */

var CoordsConverter = cc.Class.extend({

});

CoordsConverter.convertCoordinates = function(x, y, quadrant) {
    var newPoint =new cc.Point(0,0);
    var screenWidth = ResolutionManager.getInstance().getScreenWidth();
    var screenHeight = ResolutionManager.getInstance().getScreenHeight();

    if(quadrant == 2) {
        newPoint.x = x;
        newPoint.y = screenHeight - y;
    }

    return newPoint;

}
