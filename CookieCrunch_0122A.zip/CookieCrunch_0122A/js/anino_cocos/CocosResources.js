/*
 * All necessary resources will be populated by the asset loader.
 * You can also add additional resources here manually
 *
 * Created By: Neil DG
 */
var loadingScreenSplashImg = "assets/images/loading_placeholder.png";
var CocosResources = cc.Class.extend({
    _resourceMap: [
    ],
    _resourceArray:[],
    _uiResultList: [],
    _dataResultList: [],
    _stringsList: [],
    _locList: [],

    _atlasMultipack: [],
    _sharedInstance: null,

    init: function() {
        sharedInstance = this;
    },

    addResource: function(key, data, preload) {

        //cc.log("addResource: " + key);


        //if( this._resourceMap[key] != null ){
             this._resourceMap[key] = data;


        if( preload ){
           var srcMap = {src: this._resourceMap[key]};
           this._resourceArray.push(srcMap);
        }

       // }
    },

    addLocalization: function(key, locSrc) {
        this._locList[key] = locSrc;
    },

    getLocalization: function(key) {
        return this._locList[key];
    },

    addLocString: function(key, value) {
        this._stringsList[key] = value;
    },

    addSoundResource: function(soundData){

        var formats = soundData['type'].split('|');
        for( var i = 0; i < formats.length; i++){

            if(cc.AudioEngine.getInstance().isFormatSupported(formats[i])){

                //cc.log("addSoundFormat: " + soundData['id'] + " " + formats[i]);

                var soundPath = soundData['path'] + soundData['filename'] + "."+formats[i];
                this.addResource(soundData['id'],soundPath,true);
                break;
            }

        }
    },

    addParticleResource: function(particleData){



        var particlePath = particleData['path'] + particleData['filename'] + ".plist";
        var texturePath = particleData['path'] + particleData['texture'] + ".png";
        this.addResource(particleData['id'],particlePath,true);
        this.addResource(particleData['texture'],texturePath,true);


    },

    getLocString: function(key) {
        if(this._stringsList[key] == null) {
            return key;
        }
        else {
            return this._stringsList[key];
        }
    },

    addAtlasResource: function(data) {

       var count = parseInt(data['multipack']);
       for(var i=0; i < count; i++){
          var label =  data['id']+'_'+i;
          var plistSrc = data['path'] + data['filename']+i+".plist";
          var imageSrc = data['path'] + data['filename']+i+".png";
//          console.log('add atlas label : ' + label + '_PLIST');
//          console.log('add atlas resource : ' + plistSrc);
          this.addResource(label + '_PLIST', plistSrc, data['preload'] );
          this.addResource(label + '_IMG', imageSrc, data['preload'] );

//          cc.log("loaded atlas: " + label  );
       }


       this._atlasMultipack[data['id']] = count;
    },

    getAtlasNamesMulti: function(label){
        var count = this._atlasMultipack[label];
        var ret = [];

        for(var i=0; i < count; i++){
            var labelA = label+'_' +i;
            ret.push(labelA);
        }

        //console.log("multi " + JSON.stringify(ret,null,4));
        return ret;
    },

    addUIResource: function(key, jsonSrc) {


        $.getJSON(jsonSrc, function(data) {
            var result = data;
            this._uiResultList[key] = result;
        }.bind(this))
    },

    addDataResource: function(key, jsonSrc) {

        $.getJSON(jsonSrc, function(data) {
            var result = data;
            this._dataResultList[key] = result;
        }.bind(this))
    },

    getUIResource: function(key) {

        return this._uiResultList[key];
    },

    getDataResource: function(key) {

        return this._dataResultList[key];
    },

    getResource: function(key) {
        //console.log("getResource: " + key);
        return this._resourceMap[key];
    },

    getFileNameOfRes: function(key) {
        var fullPath = this.getResource(key);

        var fileName = fullPath.replace(/^.*[\\\/]/, '');

        return fileName;
    },

    hasResource: function(key) {
       return CocosGenericHelper.isInArray(this._resourceMap,key);
    },

    //returns the resource map represented as an array
    getResourceArray: function() {
        return this._resourceArray;
    }
})

CocosResources.getInstance = function() {
    if(CocosResources._sharedInstance == null){
        CocosResources._sharedInstance = new CocosResources();
        CocosResources._sharedInstance.init();
    }

    return CocosResources._sharedInstance;
}