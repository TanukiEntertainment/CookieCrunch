/**
 * Created by paolo.suarez on 1/15/14.
 */

anino.AudioEngine = cc.Class.extend({

    playMusic:function (path, loop) {

        cc.AudioEngine.getInstance().playMusic(path,loop);
    },

    isMusicPlaying: function () {

        return cc.AudioEngine.isMusicPlaying;
    },

    playEffect:function (path,loop) {

        cc.AudioEngine.getInstance().playEffect(path,loop);
    },

    toggleSound: function(){

        if( cc.AudioEngine.getInstance().getMusicVolume() > 0 ){
            this.mute();
            return;
        }

       this.unmute();

    },

    mute:function(){
        cc.AudioEngine.getInstance().setMusicVolume(0);
        cc.AudioEngine.getInstance().setEffectsVolume(0);
    },

    unmute:function(){
        cc.AudioEngine.getInstance().setEffectsVolume(1);
        cc.AudioEngine.getInstance().setMusicVolume(1);
    }

});


anino.AudioEngine._instance = null;

anino.AudioEngine.getInstance = function () {
    if (!this._instance) {
         this._instance = new anino.AudioEngine();
    }
    return this._instance;
};


