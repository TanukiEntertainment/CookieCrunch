/**
 * Created by patrick.pamplona on 1/8/14.
 */
var CocosDebugHelper = cc.Class.extend({

});

CocosDebugHelper.arrayOfPointsToString = function(arr)
{
    var ret = "ARRAY CONTENTS : \n";

    if(arr == null) { return ret + "[null]"; }

    for(var i = 0; i < arr.length; i++)
    {
        ret += "[" + i + "] : ";
        var obj = arr[i];

        try
        {
            ret += "x: " + obj.x + ", y: " + obj.y + "\n";
        }
        catch(e)
        {
            console.log("[WARNING] : Not a point.");
        }
    }

    return ret;
}

CocosDebugHelper.arrayOfRectToString = function(arr)
{
    var ret = "ARRAY CONTENTS : \n";

    if(arr == null) { return ret + "[null]"; }

    for(var i = 0; i < arr.length; i++)
    {
        ret += "[" + i + "] : ";
        var obj = arr[i];

        try
        {
            ret += "x: " + obj.x + ", y: " + obj.y + ", w: " + obj.width + ", h: " + obj.height + "\n";
        }
        catch(e)
        {
            console.log("[WARNING] : Not a rect.");
        }
    }

    return ret;
}