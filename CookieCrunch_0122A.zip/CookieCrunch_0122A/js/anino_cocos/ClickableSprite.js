/**
 * Created by patrick.pamplona on 1/8/14.
 */
var ClickableSprite = cc.Sprite.extend
({
    //touch signals
    onTouchBeganSignal: null,
    onTouchMovedSignal: null,
    onTouchEndedSignal: null,
    touched: false,

    init:function()
    {
        this.onTouchBeganSignal = new signals.Signal();
        this.onTouchMovedSignal = new signals.Signal();
        this.onTouchEndedSignal = new signals.Signal();
    },

    onEnter:function ()
    {
        this._super();
    },

    onExit:function ()
    {
        this.onTouchBeganSignal.removeAll();
        this.onTouchMovedSignal.removeAll();
        this.onTouchEndedSignal.removeAll();
        cc.unregisterTouchDelegate(this);
        this._super();
    },


    onTouchBegan:function (touch, event)
    {
        //console.log("ON TOUCH BEGAN!");
        if(this.touched) return true;
        //console.log("NOT YET TOUCHED!");
        var box = this.getBoundingBoxToWorld();
        if(cc.rectContainsPoint(box, touch.getLocation()))
        {
//            console.log("TOUCHED!");
            this.touched = true;
            this.onTouchBeganSignal.dispatch(touch.getLocation());
            return true;
        }
    },

    onTouchMoved:function (touch, event)
    {
        //only dispatch on move signals if the sprite is touched
        if(this.touched)
        {
            this.onTouchMovedSignal.dispatch(touch.getLocation());
        }
    },

    onTouchEnded:function (touch, event)
    {
        if(this.touched)
        {
            this.touched = false;
            this.onTouchEndedSignal.dispatch(touch.getLocation());
        }
    },

    touchDelegateRetain  : function () { },
    touchDelegateRelease : function () { }
});

ClickableSprite.createWithSpriteFrameName = function (spriteFrameName)
{
    var spriteFrame = null;
    if (typeof(spriteFrameName) == 'string')
    {
        spriteFrame = cc.SpriteFrameCache.getInstance().getSpriteFrame(spriteFrameName);
        if (!spriteFrame)
        {
            cc.log("Invalid spriteFrameName: " + spriteFrameName);
            return null;
        }
    }
    else
    {
        cc.log("Invalid argument. Expecting string.");
        return null;
    }

    var sprite = new ClickableSprite();
    if (sprite && sprite.initWithSpriteFrame(spriteFrame))
    {
        return sprite;
    }

    return null;
};