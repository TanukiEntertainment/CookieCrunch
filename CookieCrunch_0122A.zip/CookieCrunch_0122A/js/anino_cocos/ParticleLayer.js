/**
 * Created by paolo.suarez on 1/16/14.
 */

anino.ParticleLayer = cc.Layer.extend({



    ctor: function(){
        this._super();


    },

    listenToParticleSignals :function(signal){
        signal.add(this.onEmittedParticle.bind(this));
    },

    onEmittedParticle:function( particle,box,callback,target ){

    },

    /*
    setCallback:function (callback, target) {
        this._target = target;
        this._callback = callback;
    },

    activate:function () {
        if (this._isEnabled) {
            var locTarget = this._target, locCallback = this._callback;
            if(!locCallback)
                return ;
            if (locTarget && (typeof(locCallback) == "string")) {
                locTarget[locCallback](this);
            } else if (locTarget && (typeof(locCallback) == "function")) {
                locCallback.call(locTarget, this);
            } else
                locCallback(this);
        }
    },*/

    onEnter:function(){
        this._super();

    },

    onExit: function(){
        this._super();

    }


});

