/*
 * All necessary resources will be populated by the asset loader.
 * You can also add additional resources here manually
 *
 * Created By: Neil DG
 */

var CocosAtlasManager = cc.Class.extend({

    _sharedInstance: null,
    _spriteFrameMap: [],
    _spriteActiveOnAtlas: [],

    init: function() {
        _sharedInstance = this;
    },

    registerAtlasSingle: function(label){
//        console.log('REGISTERING ' + label);
       if( CocosGenericHelper.isInArray(CocosGenericHelper.getKeysFromDict(this._spriteFrameMap),label) ) return;
       this._spriteFrameMap[label] = CocosGenericHelper.getFramesFromAtlas(label);
       this._spriteActiveOnAtlas[label] = 0;
    },

    registerAtlasPack: function(base){
        var atlasNames = CocosResources.getInstance().getAtlasNamesMulti(base);
        for(var i=0; i<atlasNames.length; i++){
            this.registerAtlasSingle(atlasNames[i]);
        }
    },

    getSpriteFrame: function(spriteFrameId){


      var fileName = CocosResources.getInstance().getResource(spriteFrameId);
      var atlasId = this.getAtlasIdWithSpriteFrame(fileName);
     this.cacheAtlas(atlasId);
      return cc.SpriteFrameCache.getInstance().getSpriteFrame(fileName);
    },

    getSpriteFrameFromFileName: function(fileName){

        var frame =  cc.SpriteFrameCache.getInstance().getSpriteFrame(fileName);

        if( frame == null ){ return null; }
        var atlasId = this.getAtlasIdWithSpriteFrame(fileName);
        this.cacheAtlas(atlasId);
        return frame;
    },
    cacheAtlas: function(atlasId){

        if(  this._spriteActiveOnAtlas[atlasId] == null || this._spriteActiveOnAtlas[atlasId] == 0)
        {
            cc.SpriteFrameCache.getInstance().addSpriteFrames(CocosResources.getInstance().getResource(atlasId +'_PLIST'));
        }

        this._spriteActiveOnAtlas[atlasId]++;
    },

    uncacheAtlas: function(atlasId){

        this._spriteActiveOnAtlas[atlasId]--;
        if( this._spriteActiveOnAtlas[atlasId] == 0 ) {
           // cc.SpriteFrameCache.getInstance().removeSpriteFramesFromFile(CocosResources.getInstance().getResource(atlasId+'_PLIST')); //disabled buggy
        }
    },





    getAtlasIdWithSpriteFrame: function(spriteFrameId){

        var keys = CocosGenericHelper.getKeysFromDict( this._spriteFrameMap );

        for( var i = 0; i < keys.length; i++ ){
            var array = this._spriteFrameMap[keys[i]];

            if( CocosGenericHelper.isInArray(array,spriteFrameId) ){
//                console.log('frame id is found in : ' + keys[i]);
                return keys[i];
            }
        }

    }


})

CocosAtlasManager.getInstance = function() {

    if(CocosAtlasManager._sharedInstance == null) {
        CocosAtlasManager._sharedInstance = new CocosAtlasManager();
        CocosAtlasManager._sharedInstance.init();
    }

    return CocosAtlasManager._sharedInstance;
}