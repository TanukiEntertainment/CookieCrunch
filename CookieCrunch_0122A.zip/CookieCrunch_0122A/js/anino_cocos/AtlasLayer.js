/**
 * Created by paolo.suarez on 12/18/13.
 */

var AtlasLayer = cc.Layer.extend({

    _atlasLoaded: [],
    _batchNodeTag: [],
    _spriteAtlasMap: [],

    init: function(){

    },

    onEnter:function(){

        this._super();
        for(var i = 0; i < this._atlasLoaded.length; i++){
            CocosAtlasManager.getInstance().registerAtlasPack(this._atlasLoaded[i]);
        }


    },

    registerAtlas: function(atlasId){
        this._atlasLoaded.push(atlasId);
    },


    createSprite: function(spriteFrameId,isFlippedX){
        var atlasId = CocosAtlasManager.getInstance().getAtlasIdWithSpriteFrame( CocosResources.getInstance().getResource(spriteFrameId) );
        CocosAtlasManager.getInstance().cacheAtlas(atlasId);
        var sprite = cc.Sprite.createWithSpriteFrameName(CocosResources.getInstance().getResource(spriteFrameId));
        sprite.setFlippedX(isFlippedX);
        return sprite;
    },

    getSpriteFrame: function(spriteFrameId){

        //var spriteFrameFileName = CocosResources.getInstance().getResource(spriteFrameId);
        //var atlasId = CocosAtlasManager.getInstance().getAtlasIdWithSpriteFrame( spriteFrameFileName );
        //CocosAtlasManager.getInstance().cacheAtlas(atlasId);
        return CocosAtlasManager.getInstance().getSpriteFrame(spriteFrameId);

    },

    getAnimation: function(fileName){

        var frames = [];
        var i = 1;

        var anim = new cc.Animation();
        while(true){

            cc.log("anim!!!!" + fileName+i+".png");

            var frame = CocosAtlasManager.getInstance().getSpriteFrameFromFileName(fileName+i+".png");

            if( frame == null ) break;
            //var animFrame = new cc.AnimationFrame();
            //animFrame.initWithSpriteFrame(frame,0.1);
            //frames.push(animFrame);
            anim.addSpriteFrame(frame);
            i++;
        }


        return anim;
    },


    createGrabSprite: function(spriteFrameId){

        var atlasId = CocosAtlasManager.getInstance().getAtlasIdWithSpriteFrame( CocosResources.getInstance().getResource(spriteFrameId) );
        CocosAtlasManager.getInstance().cacheAtlas(atlasId);
        var grabSprite = GrabSprite.createWithSpriteFrameName(CocosResources.getInstance().getResource(spriteFrameId));

        return grabSprite;

    },

    createClickableSprite: function(spriteFrameId){
        var atlasId = CocosAtlasManager.getInstance().getAtlasIdWithSpriteFrame(CocosResources.getInstance().getResource(spriteFrameId));
        CocosAtlasManager.getInstance().cacheAtlas(atlasId);
        var clickableSprite = ClickableSprite.createWithSpriteFrameName(CocosResources.getInstance().getResource(spriteFrameId));

        return clickableSprite;
    },

    createSpriteNonBatched: function(spriteFrameId,node,depth){

        var atlasId = CocosAtlasManager.getInstance().getAtlasIdWithSpriteFrame( CocosResources.getInstance().getResource(spriteFrameId) );

        cc.log("atlasId: " + atlasId);
        CocosAtlasManager.getInstance().cacheAtlas(atlasId);
        var sprite = cc.Sprite.createWithSpriteFrameName(CocosResources.getInstance().getResource(spriteFrameId));

        this._spriteAtlasMap[sprite] = atlasId;

        node.addChild(sprite,depth);
        return sprite;

    },

    switchSpriteFrame: function(currentSprite,spriteFrameId){

        var spriteFrame = this.getSpriteFrame( spriteFrameId );

        if( currentSprite.displayFrame() == spriteFrame ) return false;

        var atlasId = this._spriteAtlasMap[currentSprite];
        delete this._spriteAtlasMap[ currentSprite ];

        CocosAtlasManager.getInstance().uncacheAtlas(atlasId);

        currentSprite.setDisplayFrame( spriteFrame  );
        this._spriteAtlasMap[currentSprite] = atlasId;

        return true;
    },

    removeSpriteNonBatched: function(sprite){

        var parent = sprite.getParent();
        var atlasId = this._spriteAtlasMap[sprite];
        parent.removeChild(sprite);
        delete this._spriteAtlasMap[ sprite ];
        CocosAtlasManager.getInstance().uncacheAtlas(atlasId);

    },

    containsTouchLocation:function (touch) {
        var getPoint = touch.getLocation();
        var myRect = this.rect();

        myRect.x += this.getPosition().x;
        myRect.y += this.getPosition().y;
        return cc.rectContainsPoint(myRect, getPoint);//this.convertTouchToNodeSpaceAR(touch));
    },

    createSpriteBatched: function(spriteFrameId,node,depth){

        var atlasId = CocosAtlasManager.getInstance().getAtlasIdWithSpriteFrame( CocosResources.getInstance().getResource(spriteFrameId) );

        cc.log("atlas: " +spriteFrameId);

        var batchNode = null;
        var batchNodeTag = atlasId+'_TAG';

        if( !CocosGenericHelper.isInArray(this._batchNodeTag,batchNodeTag) ){
            batchNode = cc.SpriteBatchNode.create(CocosResources.getInstance().getResource(atlasId + '_IMG'));
            node.addChild(batchNode,0,batchNodeTag);
            this._batchNodeTag.push(batchNodeTag);
            //console.log(""+batchNodeTag);
        }

        batchNode = node.getChildByTag(batchNodeTag);
        CocosAtlasManager.getInstance().cacheAtlas(atlasId);

        var sprite = cc.Sprite.createWithSpriteFrameName(CocosResources.getInstance().getResource(spriteFrameId));
        batchNode.addChild(sprite,depth);

        return sprite;
    },

    removeSpriteBatched: function(sprite){

        var parent = null;
        var batchNode = sprite.getBatchNode();

        var batchNodeTag = batchNode.getTag();
        var atlasId = batchNodeTag.replace("_TAG","");

        //CocosAtlasManager.getInstance().uncacheAtlas(atlasId);
        batchNode.removeChild(sprite);

        //if( batchNode.getChildrenCount() == 0 ){
        //    batchNode.getParent().removeChild( batchNode );
        //    delete this._batchNodeTag[ batchNodeTag ];
        //}
    },




    onExit: function(){

        this._super();
    }






});
