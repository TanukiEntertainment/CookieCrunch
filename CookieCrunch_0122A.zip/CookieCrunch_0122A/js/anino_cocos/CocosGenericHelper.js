/**
 * Created by paolo.suarez on 12/13/13.
 */

var CocosGenericHelper = cc.Class.extend({

});

CocosGenericHelper.getTopRight = function(rect){
  var x = rect.getX() + rect.getWidth;
  var y = rect.getY();

    return new cc.Point(x,y);
},


CocosGenericHelper.populateSceneWithLayer = function(scene,layerArr) {

    var count = layerArr.length;

    for (var i=0; i<count; i++)
    {
       var layerInfo = layerArr[i];
       cc.log("  " + layerInfo['tag']);
       var layer = new layerInfo.class();
       layer.init();
       layer.setTouchPriority(count-i);

       scene.addChild(layer,count-i,layerInfo.tag);
    }

};

CocosGenericHelper.stringToFunction = function(str) {

    var arr = str.split(".");

    var fn = (window || this);
    for (var i = 0, len = arr.length; i < len; i++) {
        fn = fn[arr[i]];
    }
    if (typeof fn !== "function") {
        throw new Error("function not found");
    }

    return  fn;
};

CocosGenericHelper.loadAtlasPair = function(base) {

    var idx = 1;
    var batchNode = null;

    while( true )
    {
        if( !CocosResources.getInstance().hasResource(base+idx+'_IMG') ) break;

        batchNode = cc.SpriteBatchNode.create(CocosResources.getInstance().getResource(base+idx+'_IMG'));
        cc.SpriteFrameCache.getInstance().addSpriteFrames(CocosResources.getInstance().getResource(base+idx+'_PLIST'));
        idx++;
    }

    return batchNode;

};

CocosGenericHelper.isInArray = function(array, search)
{
    return (array.indexOf(search) >= 0) ? true : false;
};

CocosGenericHelper.getKeysFromDict = function(dict)
{
    var keys = [];

    for (var key in dict) {
        if (dict.hasOwnProperty(key)) {
            keys.push(key);
        }
    }

    return keys;
};

CocosGenericHelper.getValuesFromDict = function(dict)
{
    var values = [];

    for (var key in dict) {
        //if (dict.hasOwnProperty(key)) {
            values.push(dict[key]);
       // }
    }

    return values;
};

CocosGenericHelper.getFramesFromAtlas = function(key)
{
    //console.log("getFramesFromAtlas " + key);
    var dict = cc.FileUtils.getInstance().dictionaryWithContentsOfFileThreadSafe(CocosResources.getInstance().getResource(key+'_PLIST'));
    var frames = dict['frames'];

    var ret = [];
    for(var key in frames){
        if(frames.hasOwnProperty(key)){
            ret.push(key);
        }
    }

    //console.log("getframesFromAtlas: " + JSON.stringify(ret,null,4));
    return ret;

};

CocosGenericHelper.setButtonText = function(btnNode, btnText, btnFontName, btnFontSize, btnColor, btnStroke, btnStrokeSize)
{
    var txt = cc.LabelTTF.create(btnText, btnFontName, btnFontSize);
    btnNode.addChild(txt);
    txt.setPosition(cc.p(btnNode.getBoundingBox().width * 0.5,btnNode.getBoundingBox().height * 0.5));
    txt.setFontFillColor(cc.c3b(223, 66, 177));

    if(btnColor != null)
    {
        txt.setFontFillColor(btnColor);
    }

    if(btnStroke != null)
    {
        if(btnStrokeSize == null) btnStrokeSize = 1;
        txt.enableStroke(btnStroke, btnStrokeSize);
    }

    return txt;
};


