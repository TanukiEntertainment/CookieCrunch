/**
 * Created by paolo.suarez on 12/17/13.
 */

const ASSETLIST_PATH = 'assets/assetlist.asset';

const TEXTURELIST_INDEX = 1;
const UILIST_INDEX = 2;
const ATLASLIST_INDEX = 3;
const DATALIST_INDEX = 4;

const SOUNDLIST_PATH = 'assets/assetlists/soundslist.asset'; //for loading of atlases
const ATLASLIST_PATH = 'assets/assetlists/atlaslist.asset'; //for loading of atlases
const TEXTURELIST_PATH = 'assets/assetlists/texturelist.asset'; //for loading of atlases
const LOCLIST_PATH = 'assets/assetlists/loclist.asset'; //for loading of localization
const UILIST_PATH = 'assets/assetlists/uilist.asset'; //for loading of localization
const DATALIST_PATH = 'assets/assetlists/datalist.asset'; //for loading of level data and other data related
const PARTICLELIST_PATH =  'assets/assetlists/particlelist.asset';

const NUM_JSON_TO_READ = 6;

var CocosAssetLoader = cc.Class.extend({

    _resourcesMapped: null,
    _loaded: [],

    init: function() {
//        console.log("Initialized asset loader");
        this._resourcesMapped = new signals.Signal();
    },

    loadAssets: function() {
        $.getJSON(ASSETLIST_PATH, this.onAssetListLoaded.bind(this));
    },

    onAssetListLoaded: function(data) {
       //var textureListPath = data[TEXTURELIST_INDEX]['path'] + data[TEXTURELIST_INDEX]['filename'];
       //var uiListPath = data[UILIST_INDEX]['path'] + data[UILIST_INDEX]['filename'];

        //load assets
        this.readAtlasList(ATLASLIST_PATH);
        this.readTextureList(TEXTURELIST_PATH);
        this.readUIList(UILIST_PATH);
        this.readDataList(DATALIST_PATH);
        this.readLocList(LOCLIST_PATH);
        this.readSoundList(SOUNDLIST_PATH);
        this.readParticleList(PARTICLELIST_PATH);

    },

    checkComplete: function() {
      console.log("Length: " +this._loaded.length+" " + this._loaded[this._loaded.length -1 ]);
        if(this._loaded.length == NUM_JSON_TO_READ){
            this._resourcesMapped.dispatch();
        }
    },

    readSoundList: function(path) {
        $.getJSON(path, this.onSoundListLoaded.bind(this));
    },

    readAtlasList: function(path) {
        $.getJSON(path, this.onAtlasListLoaded.bind(this));
    },

    readTextureList: function(path) {
        $.getJSON(path, this.onTextureListLoaded.bind(this));
    },

    readLocList: function(path) {
        $.getJSON(path, this.onLocListLoaded.bind(this));
    },

    readUIList: function(path) {
        $.getJSON(path, this.onUIListLoaded.bind(this));
    },

    readDataList: function(path) {
        $.getJSON(path, this.onDataListLoaded.bind(this));
    },

    readLevelList: function(levelListPath) {
        $.getJSON(levelListPath, this.onLevelListLoaded.bind(this));
    },

    readParticleList: function(path) {
        $.getJSON(path, this.onParticleListLoaded.bind(this));
    },

    onLevelListLoaded: function(data) {


        for(var i = 0; i < data.length; i++) {
            var level = data[i];
            var levelSrc = level['path'] + level['filename'] + ".json";

//            console.log("Level Src: " +levelSrc);
            CocosResources.getInstance().addResource(level['id'], levelSrc);
        }

        this._loaded.push('level'); this.checkComplete();
    },

    onTextureListLoaded: function(data) {

        for(var i=0; i < data.length; i++) {
            var asset = data[i];
            var src  = asset['filename'] +"."+asset['ext']; // no path since atlasing enabled
//            console.log('loading texture [ ' + asset['id'] + ' ] : ' + src );
            CocosResources.getInstance().addResource(asset['id'], src, false); //disable preloading since atlasing is implemented
        }

        this._loaded.push('textures'); this.checkComplete();
    },

    onAtlasListLoaded: function(data) {
        for(var i = 0; i < data.length; i++) {
            //console.log("Data: " +JSON.stringify(data[i]));
            //console.log('loading atlas [ ' + data[i]['id'] + ' ] : ' + data[i]['filename'] );
            CocosResources.getInstance().addAtlasResource(data[i]);
        }
        this._loaded.push('atlas'); this.checkComplete();
    },

    onUIListLoaded: function(data) {

        for(var i = 0; i < data.length; i++) {
            var asset = data[i];
            var uiJSONSrc = asset['path'] + asset['filename'] + ".json";
            CocosResources.getInstance().addUIResource(asset['id'], uiJSONSrc);
        }

        this._loaded.push('ui'); this.checkComplete();
    },

    onSoundListLoaded: function(data) {

        for(var i = 0; i < data.length; i++) {

            var asset = data[i];
            CocosResources.getInstance().addSoundResource(asset);


                /*
                var soundTypes = asset['type'].split('|');
                for( var j = 0; j < soundTypes.length; j++){
                var soundSrc = asset['path'] + asset['filename'] + "."+soundTypes[j];
                CocosResources.getInstance().addResource(asset['id']+"_"+soundTypes[j], soundSrc, true);
                } */
        }

        this._loaded.push('sound');
        this.checkComplete();
    },

    onDataListLoaded: function(data) {
        for(var i = 0; i < data.length; i++) {
            var asset = data[i];
            var uiJSONSrc = asset['path'] + asset['filename'] + ".json";
//            console.log("Level Src: " +uiJSONSrc);
            CocosResources.getInstance().addDataResource(asset['id'], uiJSONSrc);
        }

        this._loaded.push('data'); this.checkComplete();
    },

    onParticleListLoaded: function(data) {

        for(var i = 0; i < data.length; i++) {
            var asset = data[i];

            CocosResources.getInstance().addParticleResource(asset);
        }

        this._loaded.push('particle');
        this.checkComplete();
    },

    onLocListLoaded: function(data) {
        //TODO: identify loc to load by using location params. (locale = en_US)
        for(var  i = 0; i < data.length; i++) {
            var asset = data[i];
            var locSrc = asset['path'] + asset['filename'] + ".json";

            CocosResources.getInstance().addLocalization(asset['id'], locSrc);
        }

        var locale = location.search.match(/locale=([^&]*)/);
        var languageCode;
        if(locale == null) {
            languageCode = 'en_US';
        }
        else {
            languageCode = locale[1];
        }

//        console.log("Language identified: " +languageCode);

        var selectedLocSrc = CocosResources.getInstance().getLocalization(languageCode);
        $.getJSON(selectedLocSrc,  this.onStringsLoaded.bind(this));
    },

    onStringsLoaded: function(data) {

        for(var key in data) {
//            console.log("Key: " +key+ " String: " +data[key]);
            CocosResources.getInstance().addLocString(key, data[key]);
        }

        this._loaded.push('loc'); this.checkComplete();
    }


});



