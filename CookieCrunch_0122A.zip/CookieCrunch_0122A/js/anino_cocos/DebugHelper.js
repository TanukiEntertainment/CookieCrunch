/**
 * Created by patrick.pamplona on 1/8/14.
 */
var DebugHelper = cc.Class.extend({

});

DebugHelper.arrayToString = function(arr)
{
    var ret = "ARRAY CONTENTS : \n";

    if(arr == null) { return ret + "[null]"; }

    for(var i = 0; i < arr.length; i++)
    {
        ret += "[" + i + "] : ";
        var obj = arr[i];

        try
        {
            var objString = JSON.stringify(obj);
            ret += objString + "\n";
        }
        catch(e)
        {
//            console.log(typeof obj);
            if((typeof obj) == (typeof "string") || DebugHelper.isNumber(obj))
            {
                ret += obj + "\n";
            }
            else
            {
                ret += "[object]\n";
            }
        }
    }

    return ret;
}

DebugHelper.isNumber = function(num)
{
    return ! isNaN (num - 0) && num !== null && num !== "" && num !== false;
}