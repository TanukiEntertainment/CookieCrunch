/**
 * Created by patrick.pamplona on 1/8/14.
 */
var CocosActionHelper = cc.Class.extend({

});

CocosActionHelper.doActionFromObject = function(spr, param, dur, onComplete, onCompleteTarget)
{
    if(spr == null || param == null) return;
    //prioritize duration parameter, then param.duration, then default to 1 second if both are null
    dur = dur != null ? dur : param.duration != null ? param.duration : 1;

    var actionList = new Array();

    if((param.jumpx != null || param.jumpy != null) && param.jumpheight != null && param.jumpcount != null)
    {
        var _jumpx = param.jumpx == null ? spr.getPosition().x : param.jumpx;
        var _jumpy = param.jumpy == null ? spr.getPosition().y : param.jumpy;
//        console.log("JUMPING!");
        actionList.push(cc.JumpTo.create(dur, cc.p(_jumpx, _jumpy), param.jumpheight, param.jumpcount));
    }

    if(param.x != null || param.y != null)
    {
        var _x = param.x == null ? spr.getPosition().x : param.x;
        var _y = param.y == null ? spr.getPosition().y : param.y;
        actionList.push(cc.MoveTo.create(dur, cc.p(_x, _y)));
    }

    if(param.scaleX != null || param.scaleY != null)
    {
        var _scaleX = param.scaleX == null ? spr.getScale().x : param.scaleX;
        var _scaleY = param.scaleY == null ? spr.getScale().y : param.scaleY;
        actionList.push(cc.ScaleTo.create(dur, _scaleX, _scaleY));
    }

    if(param.catmull != null)
    {
        var cmPoints = param.catmull;
        var points = [];
        for(var i = 0; i < cmPoints.length; i++)
        {
            points.push(cc.p(cmPoints[i]["x"], cmPoints[i]["y"]));
        }

        if(points.length > 0) actionList.push(cc.CatmullRomTo.create(dur, points));
    }

    if(param.rotation != null)
    {
        actionList.push(cc.RotateTo.create(dur, param.rotation));
    }

    if(param.fadein != null)
    {
        actionList.push(cc.FadeIn.create(dur));
    }
    else if(param.fadeout != null)
    {
        actionList.push(cc.FadeOut.create(dur));
    }

    //if there's no action, immediately call on complete
    if(actionList.length == 0 && onComplete != null)
    {
        onComplete();
    }
    else
    {
        for(var i = 0; i < actionList.length - 1; i++)
        {
            spr.runAction(actionList[i]);
        }

        //create a sequence of action and callback
        if(onComplete != null && onCompleteTarget != null)
        {
            var sequence = cc.Sequence.create(
                actionList[actionList.length - 1],
                cc.CallFunc.create(onComplete.bind(onCompleteTarget))
            );
            spr.runAction(sequence);
        }
        else
        {
            spr.runAction(actionList[actionList.length - 1]);
        }
    }
}