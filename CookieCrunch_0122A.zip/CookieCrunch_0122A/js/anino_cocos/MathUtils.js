/**
 * Created by patrick.pamplona on 1/8/14.
 */
var MathUtils = cc.Class.extend({

});

MathUtils.randomNumberRanged = function(min, max)
{
    if(min > max)
    {
        var temp = min;
        min = max;
        max = temp;
    }
    return (Math.floor((Math.random() * max) + min));
}