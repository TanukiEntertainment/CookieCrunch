/**
 * Modifies canvas resolution to fit the screen.
 * Created by neil.delgallego on 11/29/13.
 */

var ResolutionManager = cc.Class.extend({
    _customWidth: null,
    _customHeight: null,
    _sharedInstance: null,
    _isLandscape: false,
    _rotateImageScene: null,

    init: function() {
        this._customWidth = 768;
        this._customHeight = 1024;

        //window.addEventListener('resize', this.onWindowResized.bind(this));
    },

    onWindowResized: function() {

        this.adjustResolution();

//        console.log("Width: " +cc.EGLView.getInstance().getViewPortRect().width +
//                    " Height: " +cc.EGLView.getInstance().getViewPortRect().height);

        var viewWidth = cc.EGLView.getInstance().getViewPortRect().width;
        var viewHeight = cc.EGLView.getInstance().getViewPortRect().height;

        if (viewWidth < viewHeight) {
//            console.log("PORTRAIT");
            this._isLandscape = false;
            if(this._rotateImageScene != null) {
                cc.Director.getInstance().popScene();
                this._rotateImageScene = null;
            }
        }
        else if(viewWidth > viewHeight && !this._isLandscape) {
//             console.log("LANDSCAPE. Showing rotate image!");
             this._rotateImageScene = new RotateImageScene();
             cc.Director.getInstance().pushScene(cc.TransitionFade.create(1, this._rotateImageScene));
             this._isLandscape = true;
        }
    },

    adjustResolution: function() {


        //cc.EGLView.getInstance()._adjustSizeToBrowser();

        //cc.EGLView.getInstance().adjustViewPort(true);

        cc.EGLView.getInstance().resizeWithBrowserSize(true);
        cc.EGLView.getInstance().setDesignResolutionSize(this._customWidth,this._customHeight,cc.RESOLUTION_POLICY.SHOW_ALL);


    },

    getScreenWidth: function() {
        return this._customWidth;
    },

    getScreenHeight: function() {
        return this._customHeight;
    }
})

ResolutionManager.getInstance = function() {
    if(ResolutionManager._sharedInstance == null) {
        ResolutionManager._sharedInstance = new ResolutionManager();
        ResolutionManager._sharedInstance.init();
    }

    return ResolutionManager._sharedInstance;
}
