/**
 * Created by paolo.suarez on 1/16/14.
 */

anino.ParticleManager = cc.Class.extend({

    emittedParticle: null,

    ctor: function(){
        //this._super();
        this.emittedParticle = new signals.Signal();
    },

    emitParticle: function(particle,box,callback,target,callbackDelay){
        this.emittedParticle.dispatch(particle,box,callback,target,callbackDelay);
    }


});


anino.ParticleManager._instance = null;

anino.ParticleManager.getInstance = function () {
    if (!this._instance) {
        this._instance = new anino.ParticleManager();
    }
    return this._instance;
};

