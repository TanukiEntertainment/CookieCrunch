/**
 * Created by paolo.suarez on 1/15/14.
 */
/**
 * Created by paolo.suarez on 12/18/13.
 */

var anino = cc.Class.extend({

});