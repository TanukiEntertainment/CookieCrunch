var cocos2dApp = cc.Application.extend({
    config:document.ccConfig,
    ctor:function (scene) {
        this._super();
        this.startScene = scene;
        cc.COCOS2D_DEBUG = this.config['COCOS2D_DEBUG'];
        cc.initDebugSetting();
        cc.setup(this.config['tag']);
        cc.AppController.shareAppController().didFinishLaunchingWithOptions();
    },
    applicationDidFinishLaunching:function () {
        var director = cc.Director.getInstance();

        //adjust resolution
        ResolutionManager.getInstance().adjustResolution();

        cc.AudioEngine.getInstance().init("mp3,ogg,wav");

        var assetLoader = new CocosAssetLoader();
        assetLoader.init();
        assetLoader._resourcesMapped.add(this.onResourcesMapped.bind(this));
        assetLoader.loadAssets();

        //load resources
        /*cc.LoaderScene.preload(CocosResources.getInstance().getResourceArray(), function () {
            director.replaceScene(new this.startScene());
        }, this);*/

        //workaround to load the page twice for AWS servers. Resource list are not retrieved immediately.
        /*var loadedFlag = location.search.match(/loaded=([^&]*)/);

        if(loadedFlag == null) {
            var hrefURL = location.href;
            hrefURL += "?loaded=true";
            //location.href = hrefURL;
            location.assign(hrefURL);
        }
        else {
            console.log("Already reloaded page");
        }*/

        return true;
    },

    onResourcesMapped: function() {
        //load resources
        var director = cc.Director.getInstance();
        console.log('onResourcesMapped!');
        cc.LoaderScene.preload(CocosResources.getInstance().getResourceArray(), function () {
            director.replaceScene(new this.startScene());
        }, this);
    }
});

var myApp = new cocos2dApp(MainMenuScene);